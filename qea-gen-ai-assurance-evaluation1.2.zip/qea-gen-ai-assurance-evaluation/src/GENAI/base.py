import re
import collections
from afinn import Afinn
import asyncio
from langchain_openai import AzureChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain.chains import LLMChain
import json

from litellm import completion

from src.config_file import PYTHON_COMPILER_3_10_URL, RED_TEAM_PYRIT_URL
# from pyrit.models import ChatMessage
import uuid
import subprocess
from detoxify import Detoxify
from better_profanity import profanity
from transformers import pipeline
from distutils import util
from sentence_transformers import SentenceTransformer, util
import os
from src.config_file import OPENAI_API_KEY, AZURE_OPENAI_ENDPOINT, OPENAI_API_VERSION, MODEL_ENGINE, Deployment_Name

# Set environment variables
os.environ["AZURE_API_KEY"] = OPENAI_API_KEY
os.environ["AZURE_API_BASE"] = AZURE_OPENAI_ENDPOINT
os.environ["AZURE_API_VERSION"] = OPENAI_API_VERSION
os.environ["MODEL_ENGINE"] = MODEL_ENGINE
import litellm


def calculate_context_relevance(base_sentence, sentences):
    model = SentenceTransformer("stsb-roberta-large")
    base_embedding = model.encode(base_sentence, convert_to_tensor=True)
    sentence_embeddings = model.encode(sentences, convert_to_tensor=True)
    similarities = util.pytorch_cos_sim(base_embedding, sentence_embeddings)
    print("Similar::", similarities)

    results = []
    for sentence, similarity in zip(sentences, similarities[0]):
        score = similarity.item()
        print(f"Debug: Comparing '{base_sentence}' with '{sentence}'")
        print(f"Similarity score: {score:.2f}")

        if score > 0.8:  # Threshold for high similarity
            reason = f"The similarity score is {score:.2f} because the  answer  is highly related to the base question."
        elif score > 0.5:
            reason = f"The similarity score is {score:.2f} because the  answer is somewhat related to the base question though some differences exist."
        else:
            reason = f"The similarity score is {score:.2f} because the  answer has limited similarity to the base question."

        results.append((score, reason))

        # Sort results by similarity score in descending order
    results.sort(key=lambda x: x[0], reverse=True)
    return results


# -------------------------------------Cove---step 1--question generation---------------------------------------
def get_llm_response(model_type, prompt):
    print(f"Using model: {model_type} to run prompt: {prompt[:50]}...")

    llm_deployment = None
    if model_type in ["Gpt-35-Exploration", "gpt-4o"]:
        llm_deployment = f"azure/mktg-gpt-4-omni"
    elif model_type == "Claude-V3":
        llm_deployment = 'bedrock/anthropic.claude-3-sonnet-20240229-v1:0'

    print("LLM Deployment:", llm_deployment)  # Debug print

    try:
        response = completion(
            model=llm_deployment,
            messages=[{"content": prompt, "role": "user"}]
        )
        print("LLM response:", response)  # Debug print
        return response
    except Exception as e:
        print(f"LLM Configuration error: {e}")
        return None


def cove_runner(model_type, query: str, answer: str):
    print("cove_runner called with model_type:", model_type)
    print("Query:", query)
    print("Answer:", answer)

    initial_answer = answer
    original_question = query

    generate_verification_prompt = f'''Your task is to generate specific sub-questions that are 
    directly related to the provided answer: {initial_answer}. These sub-questions should be 
    strictly concatenated with the original question: {original_question} to form a coherent and meaningful
    question. Ensure that the concatenation maintains the flow and context of the original question
    while remaining relevant to the information in the answer. The final output should not introduce
    new topics or irrelevant details.
    Note: Only include the sub-questions, formatted as a numbered list, without any additional 
    context or explanation.'''

    # Step 2: Answers Generation
    verification_response = get_llm_response(model_type, generate_verification_prompt)

    if verification_response and 'choices' in verification_response and len(verification_response['choices']) > 0:
        verification_questions_text = verification_response['choices'][0]['message']['content'].strip()
        verification_questions = verification_questions_text.split('\n')
        print("sub-questions:", verification_questions)
    else:
        raise ValueError("The verification response does not contain valid questions.")

    # Generate Verification Answers
    verification_answers = []  # Ensure this stores all Q&A pairs
    for question in verification_questions:
        final_question_prompt = f'''
                Your task is to read each question and generate an accurate and exact answer. Do not add anything extra from your end in response.
        Question: {question}
            '''
        question_response = get_llm_response(model_type, final_question_prompt)

        if question_response and 'choices' in question_response and len(question_response['choices']) > 0:
            sub_answer = question_response['choices'][0]['message']['content'].strip()
            verification_answers.append((question, sub_answer))  # Append each pair to the list
        else:
            verification_answers.append((question, "No valid answer"))

    print("sub-answers:", verification_answers)

    # Step 3: Consistency Check with detailed reasoning
    inconsistent_count = 0
    verification_details = []  # This will hold the detailed mapping

    for sub_question, sub_answer in verification_answers:
        consistency_check_prompt = f'''
        Determine whether the provided sub-answer is consistent with the original answer. 
        Provide a detailed explanation of why the sub-answer is consistent or inconsistent.
 
        Original Answer: {initial_answer}
        Sub-Question: {sub_question}
        Sub-Answer: {sub_answer}
 
        Response: Return "Consistent" or "Inconsistent" and provide a detailed explanation.
        '''
        consistency_response = get_llm_response(model_type, consistency_check_prompt)

        if consistency_response and 'choices' in consistency_response and len(consistency_response['choices']) > 0:
            consistency_result = consistency_response['choices'][0]['message']['content'].strip()

            # Track whether it's consistent or inconsistent along with the reasoning
            if "Inconsistent" in consistency_result:
                inconsistent_count += 1
                verification_details.append({
                    'sub_question': sub_question,
                    'sub_answer': sub_answer,
                    'status': "Inconsistent",
                    'explanation': consistency_result
                })
            else:
                verification_details.append({
                    'sub_question': sub_question,
                    'sub_answer': sub_answer,
                    'status': "Consistent",
                    'explanation': consistency_result
                })
        else:
            raise ValueError("The consistency response does not contain valid data.")

    # Final output
    print("-------------------------(1)------------------------------------------")
    print(f"Original question: {query}")
    print(f"Original answer: {answer}")
    print("----------------------------(2)---------------------------------------")
    print("Verification generated questions:")
    for question in verification_questions:
        print(question)
    print("------------------------------(3)-------------------------------------")
    print("Verification generated questions - Answers:")
    for sub_question, sub_answer in verification_answers:
        print(f"Q: {sub_question}\nA: {sub_answer}\n")

    print("------------------------------(4)-------------------------------------")
    for detail in verification_details:
        print(f"Q: {detail['sub_question']}")
        print(f"A: {detail['sub_answer']}")
        print(f"Status: {detail['status']}")
        print(f"Explanation: {detail['explanation']}")
        print("---------------------------------------------------")

    print(f"Consistency result: {'Consistent' if inconsistent_count == 0 else 'Inconsistent'}")
    print(f"Total inconsistent count: {inconsistent_count}")
    print("----------------------------------------------------------------------")

    return {
        'consistency_result': 1 if inconsistent_count == 0 else 0,
        'verification_question_count': len(verification_answers),
        'inconsistent_count': inconsistent_count,
        'verification_details': verification_details,  # Return detailed verification results with mapping
    }

# ------------------------------------------------cove end-----------------------------------------------------------







# ------------------------------------------------Hallucination Detection start-----------------------------------------------------------


# ------------------------------------------------Hallucination Detection end-----------------------------------------------------------

# -----------------------------------------F1 Score-------------------------------------------------------------
import collections


def f1_score(answer: str, expected: str):
    try:
        # Clean up the expected string to extract relevant content
        if "Response:" in expected:
            expected_str = expected.split("Response:", 1)[1].strip()
        else:
            expected_str = expected

        def get_tokens(text):
            return text.split()

        # Tokenize the expected and answer strings
        gold_tok = get_tokens(expected_str)
        pred_tok = get_tokens(answer)

        # Calculate common tokens and their count
        common = collections.Counter(gold_tok) & collections.Counter(pred_tok)
        num_same = sum(common.values())

        if len(gold_tok) == 0 or len(pred_tok) == 0:
            return "NA", "Error: One of the token lists is empty."

        if num_same == 0:
            return "NA", "tokens are empty"

        # Calculate precision and recall
        precision = 1.0 * num_same / len(pred_tok)
        recall = 1.0 * num_same / len(gold_tok)
        f1 = (2 * precision * recall) / (precision + recall)

        if f1 == 1.00:
            reason = "Reason for Pass:- The F1 score is above the threshold value (0.5) because it indicates that the score'1', Perfect Match: The answer matches the expected answer exactly. This means:Complete Overlap: Every token in the answer is present in the expected answer, and no extra tokens are included in the answer. Optimal Tokenization: Tokenization is perfectly aligned, ensuring accurate matches. Ideal Precision and Recall: Both precision and recall are perfect, indicating that the answer is completely accurate relative to the expected answer."
        elif f1 == 0.00:
            reason = "Reason for Failure:- The  F1 score is below the threshold value (0.5) because it indicates that the score '0', No Token Overlap: The answer and the expected answer have no matching tokens at all. This might be due to: Complete Mismatch: The answer is entirely different from the expected answer. Tokenization Errors: Tokenization might be inconsistent or incorrect, resulting in no common tokens. Calculation Errors: Mistakes in computing precision and recall (e.g., division by zero) can result in an F1 Score of 0.0."
        elif 0.01 < f1 < 0.49:
            percentage_score = round(100 * f1, 2)
            reason = f"Reason for Failure:- The  F1 score is below the threshold value (0.5) because it indicates that the score'{percentage_score}%', Minimal Token Overlap: There are a few matching tokens between the answer and the expected answer, but the overlap is very limited. This could be due to: Partial Matches: Some tokens from the answer match the expected answer, but many tokens are missing or incorrect. Tokenization Differences: Minor discrepancies in how tokens are split or normalized may lead to a low score. Low Precision or Recall: -Precision: The answer contains many irrelevant or incorrect tokens compared to the expected answer. -Recall: The answer misses many important tokens that are present in the expected answer."
        elif 0.5 < f1 < 0.69:
            percentage_score = round(100 * f1, 2)
            reason = f"Reason for Pass:- The F1 score is above the threshold value (0.5) because it indicates that the score'{percentage_score}%', Moderate Token Overlap: There is a fair amount of overlap between the answer and the expected answer, but it’s not perfect. This suggests: Significant Partial Matches: Many tokens in the answer align with the expected answer, but some important tokens are still missing. Good Tokenization: Tokenization is mostly accurate, though there might be some small inconsistencies.Balanced Precision and Recall: Both precision and recall are moderate, indicating that while the answer is somewhat accurate, there are still notable errors or omissions."
        elif 0.7 < f1 < 0.99:
            percentage_score = round(100 * f1, 2)
            reason = f"Reason for Pass:- The F1 score is above the threshold value (0.5) because it indicates that the score'{percentage_score}%', High Token Overlap: The answer largely matches the expected answer, but there are minor discrepancies. This score indicates: High Match Rate: Most tokens in the answer are present in the expected answer and vice versa. Effective Tokenization: Tokenization is generally accurate, leading to high overlap. High Precision and Recall: Both precision and recall are high, though minor errors or omissions prevent a perfect score."
        else:
            return "NA", "unexpected score value"

        return f1, reason

    except Exception as e:
        return "NA", f"Error: {str(e)}"


# ----------------------------------------BLEU-------------------------------------------------------------

from sacrebleu.metrics import BLEU

bleu_scorer = BLEU()


def bleu(answer: str, expected: str):
    # Extract the predefined answer if it contains a prefix
    if "Response:" in expected:
        result = expected.split("Response:", 1)[1].strip()
    else:
        result = expected.strip()
    expected_list = [result]

    # Calculate BLEU score
    score = bleu_scorer.sentence_score(hypothesis=answer, references=expected_list).score
    # Normalize the BLEU score from 0 to 1
    normalized_score = score / 100
    # Interpret the BLEU score
    if normalized_score == 1.00:
        reason = (
            "Reason for Pass: The BLEU score is 1, which indicates a perfect match between your actual answer and the expected answer. This usually means your answer "
            "is very similar to the acutal answer, but check if the acutal answer data is too similar to the answer.")
    elif normalized_score == 0.00:
        reason = (
            "Reason for Failure: The BLEU score is 0, indicating no matches between actual answer and the expected answer. This suggests a very different expected answer from the acutal answer.")
    elif 0.0001 < normalized_score < 0.49:
        percentage_score = round(100 * normalized_score, 2)
        reason = (
            f"Reason for Failure: The BLEU score is {percentage_score}%, indicating a low similarity between your actual answer and the expected answer. This could be due to "
            "different words or phrases, poor alignment, or brevity. To improve, align your actual answer more closely with the.")
    elif 0.5 < normalized_score < 0.79:
        percentage_score = round(100 * normalized_score, 2)
        reason = (
            f"Reason for Pass: The BLEU score is {percentage_score}%, indicating that your actual answer is reasonably close to the expected answer, but there are some differences. "
            "Improvement could be made in word choice, phrasing, or length.")
    elif 0.8 < normalized_score < 0.99:
        percentage_score = round(100 * normalized_score, 2)
        reason = (
            f"Reason for Pass: The BLEU score is {percentage_score}%, indicating a high similarity between your actual answer and the expected answer. This suggests good precision and appropriate length.")

    elif 1.00 < normalized_score:
        percentage_score = round(100 * normalized_score, 2)
        reason = (
            f"Reason for Pass: The BLEU score is {percentage_score}%, indicating a Unexpected score value is grater than 1.0")

    elif 0.01 > normalized_score:
        percentage_score = round(100 * normalized_score, 2)
        reason = (
            f"Reason for Failure: The BLEU score is {percentage_score}%, indicating a low similarity between your actual answer and the expected answer. This could be due to "
            "different words or phrases, poor alignment, or brevity. To improve, align your actual answer more closely with the.")

    else:
        return score, "Unexpected score value"

    return normalized_score, reason


# -------------------------------------------------------------------Rouge 1----------------------------------------------------------


import re
from rouge import Rouge


class ROUGE:
    def __init__(self):
        self.rouge_scorer = Rouge()  # Initialize Rouge once

    def rouge_1(self, answer, expected):
        try:
            # Clean up the expected string to extract relevant content
            if "Response:" in expected:
                result = expected.split("Response:", 1)[1].strip()
            else:
                result = expected

            exp_answer_str = result
            answer_str = answer

            # Compute ROUGE-1 scores
            scores = self.rouge_scorer.get_scores(hyps=answer_str, refs=exp_answer_str)

            # Ensure scores list is not empty and has the expected structure
            if not scores or not isinstance(scores, list) or not scores[0].get("rouge-1"):
                raise ValueError("Unexpected format or empty scores list returned.")

            score = scores[0]["rouge-1"]["f"]

            # Determine the reason based on the score
            if score == 1.00:
                reason = "Reason for Pass: The ROUGE-1 score of 1.00 indicates a perfect match. Every word in your answer matches the expected answer, including complete content coverage and exact structure."
            elif score == 0.00:
                reason = "Reason for Failure: The ROUGE-1 score of 0.00 indicates no word match with the expected answer, missing content, and different structure."
            elif 0.01 < score < 0.49:
                percentage_score = round(100 * score, 2)
                reason = f"Reason for Failure: The ROUGE-1 score of {percentage_score}% indicates a low match with the expected answer. It suggests a small number of matching words and partial content coverage."
            elif 0.5 < score < 0.79:
                percentage_score = round(100 * score, 2)
                reason = f"Reason for Pass: The ROUGE-1 score of {percentage_score}% indicates a moderate match with the expected answer. It suggests a fair number of matching words and reasonable content coverage."
            elif 0.8 < score < 0.99:
                percentage_score = round(100 * score, 2)
                reason = f"Reason for Pass: The ROUGE-1 score of {percentage_score}% indicates a high match with the expected answer. It shows good content coverage and structure."
            else:
                return "NA", "unexpected score value"

            return score, reason

        except Exception as e:
            return "NA", f"Error: {str(e)}"

    #-------------------------------------------------------rouge_2-------------------------------------------------------------------------------

    def rouge_2(self, answer, expected):
        try:
            # Clean up the expected string to extract relevant content
            if "Response:" in expected:
                result = expected.split("Response:", 1)[1].strip()
            else:
                result = expected

            exp_answer_str = result
            answer_str = answer

            # Compute ROUGE-1 scores
            scores = self.rouge_scorer.get_scores(hyps=answer_str, refs=exp_answer_str)

            # Ensure scores list is not empty and has the expected structure
            if not scores or not isinstance(scores, list) or not scores[0].get("rouge-1"):
                raise ValueError("Unexpected format or empty scores list returned.")

            score = scores[0]["rouge-2"]["f"]

            # Determine the reason based on the score
            if score == 1.00:
                reason = "Reason for Pass: The ROUGE-2 score of 1.00 indicates a perfect match. Every 2-word phrase in the answer matches exactly with those in the expected answer, including complete overlap and exact phrasing."
            elif score == 0.00:
                reason = "Reason for Failure: The ROUGE-2 score of 0.00 indicates no matching bigrams. There is no overlap in 2-word sequences between the answer and the expected answer."
            elif 0.01 < score < 0.49:
                percentage_score = round(100 * score, 2)
                reason = f"Reason for Failure: The ROUGE-2 score of {percentage_score}% indicates few matching bigrams. Only a small number of 2-word phrases in the answer match those in the expected answer."
            elif 0.5 < score < 0.79:
                percentage_score = round(100 * score, 2)
                reason = f"Reason for Pass: The ROUGE-2 score of {percentage_score}% indicates moderate matching bigrams. A fair number of 2-word phrases in the answer match the expected answer."
            elif 0.8 < score < 0.99:
                percentage_score = round(100 * score, 2)
                reason = f"Reason for Pass: The ROUGE-2 score of {percentage_score}% indicates high matching bigrams. Many 2-word phrases in the answer match those in the expected answer."
            else:
                return "NA", "unexpected score value"

            return score, reason

        except Exception as e:
            return "NA", f"Error: {str(e)}"

    #--------------------------------------------------------------------------rouge_l--------------------------------------------------------------------------

    def rouge_l(self, answer, expected):
        try:
            # Clean up the expected string to extract relevant content
            if "Response:" in expected:
                result = expected.split("Response:", 1)[1].strip()
            else:
                result = expected

            exp_answer_str = result
            answer_str = answer

            # Compute ROUGE-1 scores
            scores = self.rouge_scorer.get_scores(hyps=answer_str, refs=exp_answer_str)

            # Ensure scores list is not empty and has the expected structure
            if not scores or not isinstance(scores, list) or not scores[0].get("rouge-1"):
                raise ValueError("Unexpected format or empty scores list returned.")

            score = scores[0]["rouge-l"]["f"]

            if score == 1.00:
                reason = "Reason for Pass:- The ROUGE-LCS score is above the threshold value (0.5) because it indicates that the ROUGE-LCS Score of 1, Perfect Match: Every sequence of words in answer matches the expected answer exactly. Complete Content Coverage: All key sequences and information from the expected answer are included. Exact Structure: The order and structure of word sequences are identical to the expected answer."
            elif score == 0.00:
                reason = "Reason for Failure:- The ROUGE-LCS score is below the threshold value (0.5) because it indicates that the ROUGE-LCS Score of 0.0, No Common Sequences: There are no common sequences of words between answer and the expected answer. Complete Mismatch: answer does not reflect the word order or key content from the expected answer."
            elif 0.01 < score < 0.49:
                percentage_score = round(100 * score, 2)
                reason = f"Reason for Failure:- The ROUGE-LCS score is below the threshold value (0.5) because it indicates that the ROUGE-LCS Score of '{percentage_score}%', Few Common Sequences: There are only a few short sequences of words in common. Partial Content Overlap: Some sequences from the expected answer are included, but important parts are missing. Different Structure: The structure of word sequences is quite different from the expected answer."
            elif 0.5 < score < 0.79:
                percentage_score = round(100 * score, 2)
                reason = f"Reason for Pass:- The ROUGE-LCS score is above the threshold value (0.5) because it indicates that the ROUGE-LCS Score of '{percentage_score}%', Moderate Common Sequences: There is a reasonable amount of common word sequences. Decent Content Coverage: answer includes a fair amount of key information from the expected answer. Similar Structure: The structure of word sequences is somewhat aligned with the expected answer but not perfect."
            elif 0.8 < score < 0.99:
                percentage_score = round(100 * score, 2)
                reason = f"Reason for Pass:- The ROUGE-LCS score is above the threshold value (0.5) because it indicates that the ROUGE-LCS Score of '{percentage_score}%', High Common Sequences: Many long sequences of words are shared between answer and the expected answer. Good Content Coverage: Most key information from the expected answer is included in answer. Close Structure: The order and structure of word sequences closely match the expected answer."
            else:
                score, reason = "NA", "unexpected score value"
            return score, reason

        except Exception as e:
            return "NA", f"Error: {str(e)}"
