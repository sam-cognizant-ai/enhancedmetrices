from sentence_transformers import SentenceTransformer, util
import requests
import pandas as pd
from src import config_file
from src.GENAI.TokenHandler import TokenHandler


# Fetch the bearer token only once
def get_bearer_token(auth_credentials):
    token_handler = TokenHandler(auth_credentials['token_url'],
                                 auth_credentials['client_id'],
                                 auth_credentials['client_secret'])
    return token_handler.fetch_bearer_token()


def fetch_app_response(question, bearer_token):
    responses = []

    base_url = config_file.BASE_URL
    endpoint = f"{base_url}/search"

    if bearer_token is None:
        print("Failed to fetch bearer token. Exiting.")
        return []

    headers = {
        'Authorization': f'Bearer {bearer_token}',
        'Content-Type': 'application/json'
    }

    data = {'user_query': question}

    for i in range(3):  # Fetch 3 responses for comparison
        try:
            response = requests.get(endpoint, params=data, headers=headers)
            response.raise_for_status()
            responses.append(response.json())
        except requests.exceptions.RequestException as e:
            print(f"Error during request {i + 1}: {e}")
            responses.append({"error": str(e)})

    return responses


def hallucination_consistency(responses):
    model = SentenceTransformer("stsb-roberta-large")
    response_embeddings = model.encode(responses, convert_to_tensor=True)

    detailed_results = []  # Collecting all results
    total_score = 0.0  # To accumulate the total score

    # Ensure there are exactly 3 responses to compare
    if len(responses) != 3:
        print(f"Expected exactly 3 responses, but got {len(responses)}. Skipping.")
        return [], 0.0

    # Compare response 1 with response 2, response 2 with response 3, and response 3 with response 1
    comparisons = [
        (0, 1),  # response 1 with response 2
        (1, 2),  # response 2 with response 3
        (2, 0)   # response 3 with response 1
    ]

    for first_idx, second_idx in comparisons:
        response_a = responses[first_idx]
        response_b = responses[second_idx]

        embedding_a = response_embeddings[first_idx]
        embedding_b = response_embeddings[second_idx]

        similarity = util.pytorch_cos_sim(embedding_a, embedding_b).item()
        total_score += similarity  # Add score to total

        if similarity > 0.8:  # Threshold for high similarity
            reason = f"The similarity score is {similarity:.2f} because the responses are highly related."
        elif similarity > 0.5:
            reason = f"The similarity score is {similarity:.2f} because the responses are somewhat related, though some differences exist."
        else:
            reason = f"The similarity score is {similarity:.2f} because the responses have limited similarity."

        detailed_results.append({
            'compared_responses': f"Response {first_idx + 1} vs Response {second_idx + 1}",
            'response_' + str(first_idx + 1): response_a,
            'response_' + str(second_idx + 1): response_b,
            'similarity_score': similarity,
            'reason': reason
        })

    # Calculate average score
    average_score = total_score / 3 if responses else 0.0  # 3 comparisons
    rounded_average_score = round(average_score, 2)

    return detailed_results, rounded_average_score


def extract_questions(file_path):
    df = pd.read_excel(file_path)
    questions = df['questions'].tolist()
    return questions


def save_results_to_excel(output_path, data):
    df = pd.DataFrame(data)
    df.to_excel(output_path, index=False)
    print(f'Results saved to {output_path}')


def main():
    file_path = 'C:\\Users\\QEACHNFSTDEVTM\\Documents\\GitHub\\qea-gen-ai-assurance-evaluation\\Input\\input2.xlsx'  # Replace with your file path
    questions = extract_questions(file_path)

    # Prepare to fetch the token once
    auth_credentials = {
        "client_id": config_file.CLIENT_ID,
        "client_secret": config_file.CLIENT_SECRET,
        "token_url": config_file.TOKEN_URL
    }

    bearer_token = get_bearer_token(auth_credentials)

    # Prepare a list to hold the results for saving to Excel
    results_to_save = []

    # Process each question
    for question in questions:
        # Fetch responses from the application
        responses = fetch_app_response(question, bearer_token)

        # Debugging: Print the full responses for inspection
        print("Full API Responses:", responses)

        # Extract response texts from the responses
        response_texts = []
        for response in responses:
            # Inspect the response structure
            if isinstance(response, dict):
                if 'data' in response and 'response' in response['data']:
                    response_text = response['data']['response']
                    if response_text:  # Only add non-empty responses
                        response_texts.append(response_text)

        # Check if response texts are empty
        if not response_texts:
            print(f"No valid responses found for question: {question}. Skipping.")
            continue

        # Call the similarity function with the response texts (now comparing them with each other)
        detailed_results, rounded_average_score = hallucination_consistency(response_texts)
        print(f"______________Results for question: '{question}' ______________")

        # Prepare results for output
        for result in detailed_results:
            print(f"Comparison: {result['compared_responses']}\n"
                  f"Score: {result['similarity_score']:.2f}, Reason: {result['reason']}\n")

        # Add all details to the results_to_save list
        results_to_save.append({
            'question': question,
            # 'response_1': response_texts[0],  # First response
            # 'response_2': response_texts[1],  # Second response
            # 'response_3': response_texts[2],  # Third response
            'detailed_results': detailed_results,
            'hallucination_consistency': rounded_average_score
        })

        print(f"Average Similarity Score for question '{question}': {rounded_average_score:.2f}")

    # Save results to Excel after processing all questions
    output_path = 'C:\\Users\\QEACHNFSTDEVTM\\Documents\\GitHub\\qea-gen-ai-assurance-evaluation\\Output\\output.xlsx'  # Replace with your output file path
    save_results_to_excel(output_path, results_to_save)


if __name__ == "__main__":
    main()
