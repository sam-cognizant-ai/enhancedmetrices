import time
import requests
import json

class TokenHandler:
    def __init__(self, token_url, client_id, client_secret):
        self.TOKEN_URL = token_url  # Token URL should already include '/token'
        self.CLIENT_ID = client_id
        self.CLIENT_SECRET = client_secret

        self.EXPIRATION_TIME = 15 * 60  # Expiration time in seconds (15 minutes)
        self.bearer_token = None
        self.token_generation_count = 0

    def fetch_bearer_token(self):
        try:
            # Use the URL as-is, do not append '/token'
            payload = json.dumps({
                'client_id': self.CLIENT_ID,
                'client_secret': self.CLIENT_SECRET
            })
            headers = {
                'Content-Type': 'application/json'
            }

            response = requests.post(self.TOKEN_URL, headers=headers, data=payload)  # No appending '/token' here
            response.raise_for_status()

            token_data = response.json()
            self.bearer_token = token_data.get('access_token')
            self.token_generation_count += 1
            print(f"Token fetched successfully: {self.bearer_token}. Count: {self.token_generation_count}")
            return self.bearer_token  # <-- Ensure the token is returned
        except requests.exceptions.RequestException as e:
            print(f"Error fetching token: {e}")
            if e.response:
                print(f"Response: {e.response.text}")
            self.bearer_token = None
            return None  # <-- Return None in case of an error


    def refresh_bearer_token(self):
        while True:
            self.fetch_bearer_token()
            if self.bearer_token:
                print("Token will be refreshed in 14 minutes and 30 seconds")
                # Sleep for 14 minutes and 30 seconds, then refresh the token
                time.sleep(14 * 60 + 30)
            else:
                print("Failed to fetch token, retrying in 1 minute...")
                time.sleep(60)  # Retry after 1 minute if fetching token fails

    def start_bearer_token_refresh(self):
        self.refresh_bearer_token()