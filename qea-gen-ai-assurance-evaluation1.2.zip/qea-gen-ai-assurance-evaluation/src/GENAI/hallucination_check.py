from sentence_transformers import SentenceTransformer, util
import requests
from src import config_file
from src.GENAI.TokenHandler import TokenHandler

def fetch_app_response():
    responses = []

    base_url = config_file.BASE_URL
    question = config_file.QUESTION
    auth_credentials = {
        "client_id": config_file.CLIENT_ID,
        "client_secret": config_file.CLIENT_SECRET,
        "token_url": config_file.TOKEN_URL
    }

    endpoint = f"{base_url}/search"

    token_handler = TokenHandler(auth_credentials['token_url'], auth_credentials['client_id'], auth_credentials['client_secret'])
    bearer_token = token_handler.fetch_bearer_token()

    if bearer_token is None:
        print("Failed to fetch bearer token. Exiting.")
        return []

    headers = {
        'Authorization': f'Bearer {bearer_token}',
        'Content-Type': 'application/json'
    }

    data = {'user_query': question}

    for i in range(3):
        try:
            response = requests.get(endpoint, params=data, headers=headers)
            response.raise_for_status()
            responses.append(response.json())
        except requests.exceptions.RequestException as e:
            print(f"Error during request {i + 1}: {e}")
            responses.append({"error": str(e)})

    return responses

def extract_samples_from_responses(responses):
    """Extracts sample texts from the API responses."""
    samples = []
    for response in responses:
        # Inspect the response structure
        if isinstance(response, dict):
            print("Inspecting response:", response)
            # Extract the response string as per your API structure
            if 'data' in response and 'response' in response['data']:
                sample_text = response['data']['response']
                if sample_text:  # Only add non-empty samples
                    samples.append(sample_text)
    return samples

def calculate_context_relevance(answer_sentence, samples):
    model = SentenceTransformer("stsb-roberta-large")
    answer_embedding = model.encode(answer_sentence, convert_to_tensor=True)
    sample_embeddings = model.encode(samples, convert_to_tensor=True)
    similarities = util.pytorch_cos_sim(answer_embedding, sample_embeddings)
    print("Similarities::", similarities)

    results = []
    total_score = 0.0  # To accumulate the total score

    for sample, similarity in zip(samples, similarities[0]):
        score = similarity.item()
        total_score += score  # Add score to total
        print(f"Debug: Comparing '{answer_sentence}' with '{sample}'")
        print(f"Similarity score: {score:.2f}")

        if score > 0.8:  # Threshold for high similarity
            reason = f"The similarity score is {score:.2f} because the answer is highly related to the sample."
        elif score > 0.5:
            reason = f"The similarity score is {score:.2f} because the answer is somewhat related to the sample, though some differences exist."
        else:
            reason = f"The similarity score is {score:.2f} because the answer has limited similarity to the sample."

        results.append((score, reason))

    # Sort results by similarity score in descending order
    results.sort(key=lambda x: x[0], reverse=True)

    # Calculate average score
    average_score = total_score / len(samples) if samples else 0.0
    return results, average_score

def main():
    # Fetch responses from the application
    responses = fetch_app_response()

    # Debugging: Print the full responses for inspection
    print("Full API Responses:", responses)

    # Extract sample texts from the responses
    samples = extract_samples_from_responses(responses)

    # Debugging: Print the samples
    print("Fetched Samples:", samples)

    # Check if samples are empty
    if not samples:
        print("No valid samples found for comparison. Exiting.")
        return

    # Example answer to compare against
    answer = "Cognizant can help your business grow by leveraging innovative offerings and next-generation technology to transform the digital age. Our team of domain and technology experts can assist in building advanced capabilities—platforms, tools, and processes—to attain an enduring competitive advantage. Additionally, we apply AI to data generated from your customers and business operations, analyzing it from every angle to determine your present and future needs. By automating and scaling many parts of your business, we explore new ways to connect with customers and drive growth."

    # Call the context relevance function with the samples
    results, average_score = calculate_context_relevance(answer, samples)
    print("______________Results______________")
    for score, reason in results:
        print(f"Score: {score:.2f}, Reason: {reason}")

    print(f"\nAverage Similarity Score: {average_score:.2f}")

if __name__ == "__main__":
    main()
