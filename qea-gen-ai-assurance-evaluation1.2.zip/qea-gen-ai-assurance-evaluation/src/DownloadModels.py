from transformers import AutoModel, AutoTokenizer
from sentence_transformers import SentenceTransformer


def load_model(model_name):
    print(f"Loading model {model_name}...")
    if "stsb-roberta-large" in model_name:
        print("Sentence Transformers model detected.")
        model = SentenceTransformer(model_name)
    else:
        print("Hugging Face model detected.")
        # Load the model
        model = AutoModel.from_pretrained(model_name)
        # Load the tokenizer
        tokenizer = AutoTokenizer.from_pretrained(model_name)
    print(f"Model {model_name} loaded successfully.")


def main():
    # List of models to load
    models = [
        'sentence-transformers/paraphrase-MiniLM-L6-v2',
        'sentence-transformers/stsb-roberta-large',
        'sentence-transformers/all-MiniLM-L6-v2'
    ]

    # Load each model
    for model in models:
        load_model(model)

    print("All models loaded successfully.")


if __name__ == "__main__":
    main()
