from sentence_transformers import SentenceTransformer, util
import requests
import pandas as pd
from src import config_file
from src.GENAI.TokenHandler import TokenHandler


# Fetch the bearer token only once
def get_bearer_token(auth_credentials):
    token_handler = TokenHandler(auth_credentials['token_url'],
                                 auth_credentials['client_id'],
                                 auth_credentials['client_secret'])
    return token_handler.fetch_bearer_token()


def fetch_app_response(question, bearer_token):
    responses = []

    base_url = config_file.BASE_URL
    endpoint = f"{base_url}/search"

    if bearer_token is None:
        print("Failed to fetch bearer token. Exiting.")
        return []

    headers = {
        'Authorization': f'Bearer {bearer_token}',
        'Content-Type': 'application/json'
    }

    data = {'user_query': question}

    for i in range(3):
        try:
            response = requests.get(endpoint, params=data, headers=headers)
            response.raise_for_status()
            responses.append(response.json())
        except requests.exceptions.RequestException as e:
            print(f"Error during request {i + 1}: {e}")
            responses.append({"error": str(e)})

    return responses


def calculate_context_relevance(answer_sentence, samples):
    model = SentenceTransformer("stsb-roberta-large")
    answer_embedding = model.encode(answer_sentence, convert_to_tensor=True)
    sample_embeddings = model.encode(samples, convert_to_tensor=True)
    similarities = util.pytorch_cos_sim(answer_embedding, sample_embeddings)

    results = []
    total_score = 0.0  # To accumulate the total score

    for sample, similarity in zip(samples, similarities[0]):
        score = similarity.item()
        total_score += score  # Add score to total

        if score > 0.8:  # Threshold for high similarity
            reason = f"The similarity score is {score:.2f} because the answer is highly related to the sample."
        elif score > 0.5:
            reason = f"The similarity score is {score:.2f} because the answer is somewhat related to the sample, though some differences exist."
        else:
            reason = f"The similarity score is {score:.2f} because the answer has limited similarity to the sample."

        results.append((sample, score, reason))  # Include sample, score, and reason

    # Calculate average score
    average_score = total_score / len(samples) if samples else 0.0
    rounded_average_score = round(average_score, 2)

    return results, rounded_average_score


def extract_questions_and_answers(file_path):
    df = pd.read_excel(file_path)
    questions = df['questions'].tolist()
    answers = df['answer'].tolist()
    return questions, answers


def save_results_to_excel(output_path, data):
    df = pd.DataFrame(data)
    df.to_excel(output_path, index=False)
    print(f'Results saved to {output_path}')


def main():
    file_path = 'C:\\Users\\QEACHNFSTDEVTM\\Documents\\GitHub\\qea-gen-ai-assurance-evaluation\\Input\\inputtest.xlsx'  # Replace with your file path
    questions, answers = extract_questions_and_answers(file_path)

    # Prepare to fetch the token once
    auth_credentials = {
        "client_id": config_file.CLIENT_ID,
        "client_secret": config_file.CLIENT_SECRET,
        "token_url": config_file.TOKEN_URL
    }

    bearer_token = get_bearer_token(auth_credentials)

    # Prepare a list to hold the results for saving to Excel
    results_to_save = []

    # Process each question and corresponding answer
    for question, answer in zip(questions, answers):
        # Fetch responses from the application
        responses = fetch_app_response(question, bearer_token)

        # Debugging: Print the full responses for inspection
        print("Full API Responses:", responses)

        # Extract sample texts from the responses
        samples = []
        for response in responses:
            # Inspect the response structure
            if isinstance(response, dict):
                if 'data' in response and 'response' in response['data']:
                    sample_text = response['data']['response']
                    if sample_text:  # Only add non-empty samples
                        samples.append(sample_text)

        # Check if samples are empty
        if not samples:
            print(f"No valid samples found for question: {question}. Skipping.")
            continue

        # Call the context relevance function with the samples
        results, rounded_average_score = calculate_context_relevance(answer, samples)
        print(f"______________Results for question: '{question}' ______________")

        # Prepare results for output
        detailed_results = []
        for sample, score, reason in results:
            print(f"Sample: {sample}\nScore: {score:.2f}, Reason: {reason}\n")
            detailed_results.append({
                'sample': sample,
                'score': score,
                'reason': reason
            })

        print(f"Average Similarity Score for question '{question}': {rounded_average_score:.2f}")

        # Add all details to the results_to_save list
        results_to_save.append({
            'question': question,
            'answer': answer,
            'detailed_results': detailed_results,
            'similarity': rounded_average_score
        })

    # Save results to Excel after processing all questions
    output_path = 'C:\\Users\\QEACHNFSTDEVTM\\Documents\\GitHub\\qea-gen-ai-assurance-evaluation\\Output\\output.xlsx'  # Replace with your output file path
    save_results_to_excel(output_path, results_to_save)


if __name__ == "__main__":
    main()
