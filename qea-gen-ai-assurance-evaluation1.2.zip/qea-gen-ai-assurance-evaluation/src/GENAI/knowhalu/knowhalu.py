import os
import json
from tqdm import tqdm
from src.GENAI.knowhalu.architectures import LLMCompletion

# ----------------------------------------------utils------------------------------------------------------------
import re
from nltk.tokenize import sent_tokenize, word_tokenize


def insert_newlines(text):
    formatted_text = re.sub(r'(?<!\n)(#\w+-\d+#:)', r'\n\1', text)
    return formatted_text


def extract_query(txt):
    queries = []
    # Find the pattern with #Query-#
    pattern = r"Query-\d+#:\s*(.+?)(?=\s*#|$)|Query#:\s*(.+?)(?=\s*#|$)"
    matches = re.findall(pattern, txt)
    for match in matches:
        # Concatenate tuples from re.findall, if any
        combined_match = ''.join(match)
        if '[' in combined_match:
            # Find the last occurrence of ']'
            last_bracket_pos = combined_match.rfind(']')
            # Find the corresponding '['
            first_bracket_pos = combined_match.rfind('[', 0, last_bracket_pos)

            # Split the string into two parts
            first_query = combined_match[:first_bracket_pos].strip()
            second_query = combined_match[first_bracket_pos + 1:last_bracket_pos].strip()

            queries.append(first_query)
            queries.extend(second_query.split('; '))
        else:
            queries.append(combined_match)
    return queries


def clean_query(text):
    # Remove lines that start with #Thought-xx and #Done#
    cleaned_text = re.sub(r'#Thought-\d+#:.*|Thought-\d+#:.*|#Done#', '', text, flags=re.MULTILINE)
    # Remove lines that do not start with #Query or #Knowledge
    cleaned_text = re.sub(r'^(?!#Query|#Knowledge|Query|Knowledge).*$', '', cleaned_text, flags=re.MULTILINE)
    # Remove excessive newlines
    cleaned_text = re.sub(r'\n\s*\n', '\n', cleaned_text)
    return cleaned_text.strip()


def split_summary_into_parts(summary, word_limit=30):
    sentences = sent_tokenize(summary.strip())
    summary_parts = []
    current_part = []
    current_word_count = 0

    for sentence in sentences:
        word_count = len(word_tokenize(sentence))
        if current_word_count + word_count > word_limit:
            # If adding this sentence exceeds word_limit words, process the current part
            summary_parts.append(' '.join(current_part))
            current_part = [sentence]
            current_word_count = word_count
        else:
            # Otherwise, add this sentence to the current part
            current_part.append(sentence)
            current_word_count += word_count

    # Add the last part if it's not empty
    if current_part:
        summary_parts.append(' '.join(current_part))

    return summary_parts


# -------------------------------------------------------------------------------------------------------------------------------
class hallucination:
    def __init__(self, query, answers, context, args_model='gpt-3.5-turbo-1106', args_form='semantic',
                 args_topk=2, args_answer_type='right', args_knowledge_type='ground',
                 args_query_selection=1, args_save_freq=10, args_count_limit=10, args_resume=False):
        self.questions = [query]
        self.answers = [answers]
        self.context = context
        self.args_model = args_model
        self.args_form = args_form
        self.args_topk = args_topk
        self.args_answer_type = args_answer_type
        self.args_knowledge_type = args_knowledge_type
        self.args_query_selection = args_query_selection
        self.args_save_freq = args_save_freq
        self.args_count_limit = args_count_limit
        self.args_resume = args_resume

    def execute_qa_process(self):
        if not self.context:
            return "NA"
        current_dir = os.path.dirname(os.path.abspath(__file__))
        print(f"Current directory: {current_dir}")
        prompts_dir = os.path.join(current_dir, 'prompts')


        # Read instructions
        if self.args_query_selection is not None:
            suffix = f'_selection{self.args_query_selection}'
        else:
            suffix = ''

        file_name = f'query_{self.args_form}{suffix}.txt'
        file_path = os.path.join(prompts_dir, file_name)

        with open(file_path,'r', encoding="utf-8") as f:
            main_instruction = f.read()

        knowledge_file_name = f'retrieve_{self.args_knowledge_type}_{self.args_form}{suffix}.txt'
        knowledge_file_path = os.path.join(prompts_dir, knowledge_file_name)

        with open(knowledge_file_path, 'r', encoding="utf-8") as f:
            knowledge_instruction = f.read()

        stop_tokens = ['#Knowledge', '\n\n']
        llm = LLMCompletion(self.args_model)

        file_name = os.path.join(current_dir, 'results/qa/query_knowledge/{self.args_model}/{self.args_answer_type}_{self.args_knowledge_type}_{self.args_form}')

        if self.args_knowledge_type == 'wiki':
            file_name += f'_top{self.args_topk}'
        if self.args_query_selection is not None:
            file_name += f'_q{self.args_query_selection}'
        file_name += '.json'

        directory = os.path.dirname(file_name)
        if not os.path.exists(directory):
            os.makedirs(directory)

        if self.args_resume:
            try:
                with open(file_name, 'r') as f:
                    query_knowledge = json.load(f)
            except:
                query_knowledge = ['' for _ in range(len(self.questions))]
                print("No checkpoint file found, starting from scratch.")
        else:
            query_knowledge = ['' for _ in range(len(self.questions))]

        for i in tqdm(range(len(self.questions))):
            if query_knowledge[i] != '':
                continue
            count = 0
            prompt = main_instruction.format(question=self.questions[i], answer=self.answers[i])
            prompt_length = len(prompt)
            prompt += '#Thought-1#:'
            current_output = llm(prompt, stop_tokens)
            count += 1
            if self.args_model.startswith('gpt'):
                prompt += ' ' + current_output
            else:
                prompt += current_output
            while count < self.args_count_limit:
                if '\n\n' in current_output:
                    output = prompt[prompt_length:].strip()
                    query_knowledge[i] = output
                    print(output)
                    break
                elif current_output.endswith('#Knowledge') or (
                        self.args_model.startswith('gpt') and '\n' == current_output[-1:]) or (
                        'Query-' in current_output.split('\n')[-1]):
                    if 'Query-' in current_output.split('\n')[-1]:
                        current_output += '\n'
                    query = extract_query(current_output)
                    if len(query) == 0:
                        last_newline_index = prompt.rfind('\n')
                        prompt = prompt[:last_newline_index]
                        prompt += f'\n#Query-{count}#:'
                        current_output = llm(prompt, stop_tokens)
                        prompt += current_output
                        query = extract_query(f'#Query-{count}#:' + current_output)
                        if len(query) == 0:
                            import pdb;
                            pdb.set_trace()

                    knowledge = self.context[i] if self.args_knowledge_type == 'ground' else wiki_retrieval(query,
                                                                                                            self.args_topk)
                    if self.args_query_selection is not None or len(query) < 2:
                        knowledge_prompt = knowledge_instruction.format(question=query[0], knowledge=knowledge)
                    else:
                        knowledge_prompt = knowledge_instruction.format(question=f'{query[0]} [{query[1]}]',
                                                                        knowledge=knowledge)
                    knowledge_output = llm(knowledge_prompt).split('\n')[0]
                    if self.args_model.startswith('gpt'):
                        if not prompt.endswith('\n'):
                            prompt += '\n'
                        prompt += f'#Knowledge-{count}#: ' + knowledge_output + f'\n#Thought-{count + 1}#:'
                    else:
                        if not prompt.endswith('\n#Knowledge'):
                            prompt += '\n#Knowledge'
                        prompt += f'-{count}#:' + knowledge_output + f'\n#Thought-{count + 1}#:'
                else:
                    output = prompt[prompt_length:].strip()
                    query_knowledge[i] = output
                    print(output)
                    break

                current_output = llm(prompt, stop_tokens)
                count += 1
                if self.args_model.startswith('gpt'):
                    prompt += ' ' + current_output
                else:
                    prompt += current_output

            # Save intermediate results
            if (i + 1) % self.args_save_freq == 0 or i == len(self.questions) - 1:
                with open(file_name, 'w') as f:
                    json.dump(query_knowledge, f)

        # Process judgments
        judgment_file = file_name.replace('query_knowledge', 'judgment')

        directory = os.path.dirname(judgment_file)
        if not os.path.exists(directory):
            os.makedirs(directory)

        with open(file_name, 'r') as f:
            query_knowledges = json.load(f)

        if self.args_query_selection is not None:
            suffix = f'_selection{self.args_query_selection}'
        else:
            suffix = ''

        prompts_dir = os.path.join(current_dir, 'prompts')
        file_name = f'judge_{self.args_form}{suffix}.txt'
        file_path = os.path.join(prompts_dir, file_name)
        with open(file_path,'r', encoding="utf-8") as f:

            main_instruction1 = f.read()

        llm = LLMCompletion(self.args_model)

        # Resume functionality for judgments
        if self.args_resume:
            try:
                with open(judgment_file, 'r') as f:
                    judgments = json.load(f)
            except FileNotFoundError:
                judgments = [[] for _ in range(len(self.questions))]
                print("No checkpoint file found, starting from scratch.")
        else:
            judgments = [[] for _ in range(len(self.questions))]

        # Process judgments
        for i in tqdm(range(len(self.questions))):
            if judgments[i]:
                continue

            query_knowledge = clean_query(insert_newlines(query_knowledges[i]))
            prompt = main_instruction1.format(question=self.questions[i], answer=self.answers[i],
                                              query_knowledge=query_knowledge)
            current_output = llm(prompt, return_prob=None)
            judgments[i].extend(current_output)
            print(current_output[0])

            if (i + 1) % self.args_save_freq == 0 or i == len(query_knowledges) - 1:
                with open(judgment_file, 'w') as f:
                    json.dump(judgments, f)
                    joined_string = ''.join(judgments[0])
                    print(f"reason:- " + joined_string)
                    if " CORRECT" in joined_string:
                        return 0, joined_string
                        # return "NOT HALLUCINATED"
                    elif "INCORRECT" in joined_string:
                        return 1, joined_string
                        # return "HALLUCINATED"
                    else:
                        return "0", joined_string
                        # return "INCONCLUSIVE"