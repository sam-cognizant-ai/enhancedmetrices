from selfcheckgpt.modeling_selfcheck import SelfCheckBERTScore, SelfCheckNLI


def hallucination_check(passage, sample1, sample2, sample3):
    # Normalize samples
    samples = [sample.strip() for sample in [sample1, sample2, sample3]]

    # Log the samples for debugging
    print("Normalized Samples:")
    for i, sample in enumerate(samples):
        print(f"Sample {i + 1}: {sample}")

    # Instantiate the BERTScore model
    selfcheck_bertscore = SelfCheckBERTScore()

    # Instantiate the NLI model (forcing it to run on CPU)
    selfcheck_nli = SelfCheckNLI(device='cpu')

    # Predict BERTScore for each sample individually
    bert_scores = [selfcheck_bertscore.predict([passage], [sample])[0] for sample in samples]

    # Predict NLI score for each sample individually
    nli_scores = [selfcheck_nli.predict(sentences=[passage], sampled_passages=[sample])[0] for sample in samples]

    # Create a dictionary with the scores
    results = {
        "BERTScore": {
            f"sample{i + 1}": bert_scores[i] for i in range(len(samples))
        },
        "NLI": {
            f"sample{i + 1}": nli_scores[i] for i in range(len(samples))
        }
    }

    return results


# Example Usage
if __name__ == "__main__":
    passage = """Cognizant is one of the world’s leading professional services companies, transforming clients’ business, operating, and technology models for the digital era. Our unique industry-based, consultative approach helps clients envision, build, and run more innovative and efficient businesses. Cognizant offers a wide range of products, solutions, and deployment models for Medicare, Medicaid, and other government lines of business to help support operational objectives and business goals. Learn more about how Cognizant helps clients lead with digital at www.cognizant.com."""

    # Responses from the application endpoint (you need to fill these with actual data)
    sample1 = "Cognizant is one of the world’s leading professional services companies, transforming clients’ business, operating, and technology models for the digital era. Our unique industry-based, consultative approach helps clients envision, build, and run more innovative and efficient businesses. Cognizant offers a wide range of products, solutions, and deployment models for Medicare, Medicaid, and other government lines of business to help support operational objectives and business goals. Learn more about how Cognizant helps clients lead with digital at www.cognizant.com."
    sample2 = "Cognizant is one of the world’s leading professional services companies, transforming clients’ business, operating, and technology models for the digital era. Our unique industry-based, consultative approach helps clients envision, build, and run more innovative and efficient businesses. Cognizant offers a wide range of products, solutions, and deployment models for Medicare, Medicaid, and other government lines of business to help support operational objectives and business goals. Learn more about how Cognizant helps clients lead with digital at www.cognizant.com."
    sample3 = "Cognizant is one of the world’s leading professional services companies, transforming clients’ business, operating, and technology models for the digital era. Our unique industry-based, consultative approach helps clients envision, build, and run more innovative and efficient businesses. Cognizant offers a wide range of products, solutions, and deployment models for Medicare, Medicaid, and other government lines of business to help support operational objectives and business goals. Learn more about how Cognizant helps clients lead with digital at www.cognizant.com."

    # Call the hallucination check function
    results = hallucination_check(passage, sample1, sample2, sample3)

    # Print the results
    print("### BERTScore and NLI Results\n")
    for metric, scores in results.items():
        print(f"{metric} Scores:")
        for sample, score in scores.items():
            print(f"{sample}: {score}")
        print("\n")
