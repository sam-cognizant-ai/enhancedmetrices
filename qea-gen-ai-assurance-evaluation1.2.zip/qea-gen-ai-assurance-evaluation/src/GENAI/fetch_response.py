from src import config_file
from src.GENAI.TokenHandler import TokenHandler
import requests
import os


def fetch_app_response():

    responses = []

    base_url = config_file.BASE_URL
    question = config_file.QUESTION
    # Fetch sensitive information from the config file
    auth_credentials = {
        "client_id": config_file.CLIENT_ID,
        "client_secret": config_file.CLIENT_SECRET,
        "token_url": config_file.TOKEN_URL
    }

    # Use the /search endpoint
    endpoint = f"{base_url}/search"

    # Authenticate and retrieve a bearer token
    token_handler = TokenHandler(auth_credentials['token_url'], auth_credentials['client_id'], auth_credentials['client_secret'])
    bearer_token = token_handler.fetch_bearer_token()

    if bearer_token is None:
        print("Failed to fetch bearer token. Exiting.")
        return []

    headers = {
        'Authorization': f'Bearer {bearer_token}',
        'Content-Type': 'application/json'
    }

    # Prepare the data payload for the query
    data = {'user_query': question}

    # Fetch the response three times
    for i in range(3):
        try:
            response = requests.get(endpoint, params=data, headers=headers)  # Use params to send query
            response.raise_for_status()  # Raise an error for bad responses
            responses.append(response.json())  # Append the JSON response
        except requests.exceptions.RequestException as e:
            print(f"Error during request {i + 1}: {e}")
            responses.append({"error": str(e)})  # Log error response

    return responses


# Example usage
if __name__ == '__main__':
    results = fetch_app_response()
    print("Responses:", results)
