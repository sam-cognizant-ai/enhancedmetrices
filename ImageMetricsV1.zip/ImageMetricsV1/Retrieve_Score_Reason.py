import re


def get_score_and_reason(metric, response):
    if metric and response:
        score_match = re.search(r"Score:[^\d]*([0-9]*\.?[0-9]+)", response)
        reason_match = re.search(r"Reason:\s*(.*?)(?:\n\n|$)", response, re.DOTALL)
        co_ordinates_match = re.search(r"Co-ordinates:\s*(.*)", response, re.DOTALL)
        recommendations_match = re.search(r"Recommendations:\s*(.*)", response, re.DOTALL)
        analysis_details = {}
        if score_match and reason_match:
            llm_score = float(score_match.group(1))
            reason = reason_match.group(1).strip()
            co_ordinates = co_ordinates_match.group(1).strip() if co_ordinates_match else "NA"
            recommendations = recommendations_match.group(1).strip() if recommendations_match else "NA"

            if llm_score > 0:
                analysis_details = {
                    metric: llm_score > 0,
                    'score': llm_score,
                    'reason': reason,
                    'co-ordinates': co_ordinates,
                    'recommendations': recommendations
                }
            elif llm_score == 0:
                analysis_details = {
                    metric: False,
                    'score': 0,
                    'reason': reason,
                    'co-ordinates': co_ordinates,
                    'recommendations': recommendations
                }
        else:
            analysis_details = {
                metric: "Not evaluated",
                'score': -1,
                'reason': "There was an issue evaluating the image.",
                'recommendations': "Not provided"
            }
        return analysis_details
    else:
        return {}



