import pandas as pd
import torch
# from src.GENAI.DataGenDbOperations import DataGenerator
# from src.Utilities.SetupUtilities import setup_utilities
from src.GENAI.EvaluationEngineAsync import Feedback
from src.Utilities.utils import unique_id_generator
from src.config_file import config
from datetime import datetime
from flask import send_file
from io import BytesIO
import time
import asyncio
# from src.Constants import CURRENT_METRICS
from pprint import pprint
# Add these imports if not already present
import pandas as pd
import json


file_path = 'C:\\Users\\QEACHNFSTDEVTM\\Documents\\GitHub\\qea-gen-ai-assurance-evaluation\\Input\\inputtest.xlsx'  # Replace with the path to your Excel file
df = pd.read_excel(file_path)

class EvaluationAsync:
    total_latency = 0
    total_cost = 0
    total_words = 0
    total_characters = 0

    def __init__(self, csvdata_df):
        # Assume csvdata_df is a DataFrame loaded with relevant data
        self.csvdata_obj = csvdata_df
        self.results = []

    def evaluation_calculation(self):
        try:
            # Combine context[0] and context[1] into a single 'context' column
            self.csvdata_obj['context'] = self.csvdata_obj['context[0]'].astype(str) + " " + self.csvdata_obj['context[1]'].astype(str)

            # Use the DataFrame with the combined 'context' column
            data_df = self.csvdata_obj[['questions', 'answer', 'context']]
            model = 'gpt-4o'
            async_execution = asyncio.run(self.asyncExeFun(data_df, model))
            pprint(async_execution)

            # Save results to the results list
            self.results = async_execution

            # Flatten the results and save to Excel
            flattened_data = self.flatten_results(self.results)
            self.save_results_to_excel(flattened_data, column_to_remove='metrics')  # Specify the column to remove

        except Exception as e:
            print('Error:', str(e))

    async def asyncExeFun(self, data_df, model):
        try:
            combineList = []
            for index, row in data_df.iterrows():
                feedback = await self.process_feedback(row, model)
                print("Feedback in AsyncExeFun Return:", feedback)
                combineList.append(feedback)
                await asyncio.sleep(1)

            return combineList
        except Exception as exc:
            print('Error:', str(exc))

    async def process_feedback(self, row, model):
        try:
            start_time = time.time()

            feedback = Feedback(row['questions'], row['answer'], row['context'], model)
            # enabled_metrics = ["qa_relevance","qc_relevance","factuality"]
            enabled_metrics = ["cove"]

            all_metrics, valid_metrices, invalid_metrices, latency, cost, words, characters = await self.call_functions(feedback, enabled_metrics)

            truLens_metrics = {}
            trustworthy_metrices = {}
            metrics_valuation = {}
            metadata_metrics = {}

            metrics_list = [(k, v) for k, v in all_metrics.items()]

            for (function_name, (is_valid, result)), display_name in zip(metrics_list, enabled_metrics):
                if is_valid:
                    if function_name == "llm_similarity":
                        truLens_metrics["llm similarity score"] = result[0]
                        truLens_metrics["semantic similarity score"] = result[1]
                    elif function_name not in ["toxicity", "language_match", "cosine_similarity", "jailbreak",
                                              "adversarial_attack", "red_teaming", "f1_score",
                                              "bleu", "rouge_1", "rouge_2", "rouge_l", "meteor_score", "hallucination",
                                              "profanity", "consistent", "is_unethical", "professionalism"]:
                        truLens_metrics[display_name] = result[0]
                        truLens_metrics[f'{display_name}_REASON'] = result[1]

                        metadata_metrics["latency"] = f"{round(latency, 2)} s"
                        metadata_metrics["cost"] = f"${round(cost, 4)}"
                        metadata_metrics['total_words'] = words
                        metadata_metrics['total_char'] = characters

                    elif function_name in ["profanity", "cove", "is_unethical", "professionalism", "f1_score",
                                           "bleu", "rouge_1", "rouge_2", "rouge_l", "meteor_score", "hallucination"]:
                        truLens_metrics[display_name] = result[0]
                        truLens_metrics[f'{display_name}_reason'] = result[1]
                    else:
                        truLens_metrics[display_name] = result
                else:
                    print(f"Error occurred while processing metric '{display_name}': {result[0]}")

            latency_rounded = round(feedback.latency, 4)  # Round to 2 decimal places

            # Calculating execution time
            end_time = (time.time() - start_time) * 100

            # Constructing combined data
            combined_data = {
                'questions': row['questions'],
                'answer': row['answer'],
                'context': row['context'],
                'metrics': truLens_metrics,
            }

            print("metrics====", combined_data['metrics'])
            return combined_data

        except Exception as e:
            import sys
            print('in error', str(e), sys.exc_info()[-1].tb_lineno)

    async def call_function_with_timeout(self, feedback, func, func_name, timeout):
        try:
            print(f"Starting function '{func_name}' with {feedback.query}...")
            result = await asyncio.wait_for(func(), timeout)
            print(f"Function '{func_name}' completed successfully")
            return func_name, result, None
        except asyncio.TimeoutError:
            print(f"Function '{func_name}' timed out")
            return func_name, None, "timeout"
        except Exception as e:
            print(f"Function '{func_name}' raised an exception: {e}")
            return func_name, None, f"exception: {e}"

    async def call_functions(self, feedback, function_names, timeout=3000):
        tasks = []
        results = {}
        valid_metrices = []
        invalid_metrices = []

        if not function_names:
            print("No function name selected")
            return results, valid_metrices, invalid_metrices

        standard_metrics = [fn for fn in function_names if not fn.startswith("custom_")]

        for func_name in standard_metrics:
            if hasattr(feedback, func_name):
                func = getattr(feedback, func_name)
                task = asyncio.create_task(self.call_function_with_timeout(feedback, func, func_name, timeout))
                tasks.append(task)
                valid_metrices.append(func_name)
            else:
                print(f"Function '{func_name}' not found in 'feedback' object.")
                invalid_metrices.append(func_name)

        completed_tasks = await asyncio.gather(*tasks)

        self.total_latency += feedback.latency
        self.total_cost += feedback.totalcost
        self.total_words += feedback.total_word
        self.total_characters += feedback.total_characters

        for func_name, result, error in completed_tasks:
            if error:
                results[func_name] = (False, error)
            else:
                results[func_name] = (True, result)

        return results, valid_metrices, invalid_metrices, feedback.latency, feedback.totalcost, feedback.total_word, feedback.total_characters

    def flatten_results(self, results):
        flattened_data = []
        for entry in results:
            flattened_entry = entry.copy()
            metrics = entry.pop('metrics', {})
            flattened_entry.update(metrics)
            flattened_data.append(flattened_entry)
        return flattened_data

    def save_results_to_excel(self, flattened_data, column_to_remove=None):
        df = pd.DataFrame(flattened_data)

        # Remove the specified column if it exists
        if column_to_remove and column_to_remove in df.columns:
            df = df.drop(columns=[column_to_remove])

        output_path = 'C:\\Users\\QEACHNFSTDEVTM\\Documents\\GitHub\\qea-gen-ai-assurance-evaluation\\Output\output.xlsx'
        df.to_excel(output_path, index=False)
        print(f'Results saved to {output_path}')

evalasync = EvaluationAsync(df)
evalasync.evaluation_calculation()
