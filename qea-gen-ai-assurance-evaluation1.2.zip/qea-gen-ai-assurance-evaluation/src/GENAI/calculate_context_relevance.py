from sentence_transformers import SentenceTransformer, util

def calculate_context_relevance(answer_sentence, samples):
    model = SentenceTransformer("stsb-roberta-large")
    answer_embedding = model.encode(answer_sentence, convert_to_tensor=True)
    sample_embeddings = model.encode(samples, convert_to_tensor=True)
    similarities = util.pytorch_cos_sim(answer_embedding, sample_embeddings)
    print("Similarities::", similarities)

    results = []
    total_score = 0.0  # To accumulate the total score

    for sample, similarity in zip(samples, similarities[0]):
        score = similarity.item()
        total_score += score  # Add score to total
        print(f"Debug: Comparing '{answer_sentence}' with '{sample}'")
        print(f"Similarity score: {score:.2f}")

        if score > 0.8:  # Threshold for high similarity
            reason = f"The similarity score is {score:.2f} because the answer is highly related to the sample."
        elif score > 0.5:
            reason = f"The similarity score is {score:.2f} because the answer is somewhat related to the sample, though some differences exist."
        else:
            reason = f"The similarity score is {score:.2f} because the answer has limited similarity to the sample."

        results.append((score, reason))

    # Sort results by similarity score in descending order
    results.sort(key=lambda x: x[0], reverse=True)

    # Calculate average score
    average_score = total_score / len(samples) if samples else 0.0
    return results, average_score

def main():
    # Example input
    answer = "Cognizant is one of the world’s leading professional services companies, transforming clients’ business, operating, and technology models for the digital era. Our unique industry-based, consultative approach helps clients envision, build, and run more innovative and efficient businesses. Cognizant offers a wide range of products, solutions, and deployment models for Medicare, Medicaid, and other government lines of business to help support operational objectives and business goals. Learn more about how Cognizant helps clients lead with digital at www.cognizant.com."
    samples = [
        "Cognizant is one of the world’s leading professional services companies, transforming clients’ business, operating, and technology models for the digital era. Our unique industry-based, consultative approach helps clients envision, build, and run more innovative and efficient businesses. Cognizant offers a wide range of products, solutions, and deployment models for Medicare, Medicaid, and other government lines of business to help support operational objectives and business goals. Learn more about how Cognizant helps clients lead with digital at www.cognizant.com.",
        "Cognizant can help your business grow by leveraging innovative offerings and next-generation technology to transform the digital age. Our team of domain and technology experts can assist in building advanced capabilities—platforms, tools, and processes—to attain an enduring competitive advantage. Additionally, we apply AI to data generated from your customers and business operations, analyzing it from every angle to determine your present and future needs. By automating and scaling many parts of your business, we explore new ways to connect with customers and drive growth.",
        "Cognizant is one of the world’s leading professional services companies, transforming clients’ business, operating, and technology models for the digital era. Our unique industry-based, consultative approach helps clients envision, build, and run more innovative and efficient businesses. Cognizant offers a wide range of products, solutions, and deployment models for Medicare, Medicaid, and other government lines of business to help support operational objectives and business goals. Learn more about how Cognizant helps clients lead with digital at www.cognizant.com."
    ]

    results, average_score = calculate_context_relevance(answer, samples)
    print("______________Results______________")
    for score, reason in results:
        print(f"Score: {score:.2f}, Reason: {reason}")

    print(f"\nAverage Similarity Score: {average_score:.2f}")

if __name__ == "__main__":
    main()