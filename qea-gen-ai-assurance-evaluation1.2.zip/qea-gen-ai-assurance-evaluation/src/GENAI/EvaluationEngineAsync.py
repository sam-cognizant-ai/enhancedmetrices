import asyncio
import os
import time
import json
import torch
from nlpaug.augmenter.word import model_types

from rouge import Rouge

from sacrebleu import BLEU
from trulens_eval.feedback.provider.hugs import Huggingface

from src.GENAI.knowhalu.knowhalu import hallucination
# from src.GENAI.unethical_detection import harmfulness_detector
from trulens_eval.feedback.provider import AzureOpenAI
from langkit.openai import OpenAIAzure
from src.Utilities.SimilarityFilter import similarity_filter
# from src.GENAI.ExtendedTrulensEvaluations import CustomAzureOpenAI
import numpy as np
import ast

# from src.LlmLayer.CustomMetricesScript import CustomMetrices
from src.Utilities.utils import safe_json_loads
from src.GENAI.Count import count_characters_and_words
from src.GENAI.base import (f1_score, bleu, BLEU, ROUGE, calculate_context_relevance, cove_runner)

from src.config_file import OPENAI_API_KEY, AZURE_OPENAI_ENDPOINT, OPENAI_API_VERSION, HUGGINGFACE_API_KEY, \
    Deployment_Name, SERVICE_NAME, REGION_NAME, AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, config
# from src.GENAI.PiiDetection import PiiDetector
from trulens_eval.feedback.provider.litellm import LiteLLM
from src.LlmLayer.LiteLLM import LiteLlm as LiteLlm_Obj
from litellm import completion_cost
from src.GENAI.ExtendedTrulensEvaluations import CustomLLM

# from src.GENAI.base import Addedmetrics
# log_info = litellm.set_verbose = True
os.environ["AZURE_API_KEY"] = OPENAI_API_KEY
os.environ["AZURE_API_BASE"] = AZURE_OPENAI_ENDPOINT
os.environ["AZURE_API_VERSION"] = OPENAI_API_VERSION
os.environ["HUGGINGFACE_API_KEY"] = HUGGINGFACE_API_KEY
# Claude ENV variables
os.environ["SERVICE_NAME"] = SERVICE_NAME
os.environ["AWS_REGION_NAME"] = REGION_NAME
os.environ["AWS_ACCESS_KEY_ID"] = AWS_ACCESS_KEY_ID
os.environ["AWS_SECRET_ACCESS_KEY"] = AWS_SECRET_ACCESS_KEY
# litellm = LiteLLM(model_engine="azure/gpt35exploration")
# litellm = CustomLLM(model_engine="azure/gpt35exploration")
litellm = CustomLLM(model_engine="azure/mktg-gpt-4-omni")
# litellmClaude = LiteLLM(model_engine="bedrock/anthropic.claude-instant-v1")
# litellmClaude = LiteLLM(model_engine="bedrock/anthropic.claude-3-haiku-20240307-v1:0")
litellmClaude = CustomLLM(model_engine="anthropic.claude-3-sonnet-20240229-v1:0")
hug_provider = Huggingface()
# pii_detector = PiiDetector()
unethical_obj = LiteLlm_Obj()


# baseobj = Addedmetrics()


class Feedback:

    # def __init__(self, query=None, answer=None, context=None,model=None, usecase=None, no_of_templates=1, prompt=None, testcase=None, additional_context=None):
    def __init__(self, query=None, answer=None, context=None, model=None, usecase=None, no_of_templates=None,
                 prompt=None, testcase=None, additional_context=None):

        self.model_type = model
        self.query = query
        self.answer = answer
        self.context = context
        self.model = model
        self.latency = 0
        self.totalcost = 0
        self.total_tokens = 0
        self.total_word = 0
        self.total_characters = 0
        self.usecase = usecase
        self.no_of_templates = no_of_templates
        self.prompt = prompt
        self.testcase = testcase
        self.additional_context = additional_context
        print("model from evaluation engine", self.model)
        print(f"query: {self.query} \nanswer:{self.answer} \ncontext:{self.context}")
        if self.model == "Gpt-35-Exploration":
            self.litellm = CustomLLM(model_engine="azure/gpt35exploration")
        elif self.model == "gpt-4o":
            self.litellm = CustomLLM(model_engine="azure/mktg-gpt-4-omni")
        elif self.model == "Claude-V3":
            self.litellm = CustomLLM(model_engine="bedrock/anthropic.claude-3-sonnet-20240229-v1:0")

    async def async_method_wrapper(self, sync_method, *args, **kwargs):
        await asyncio.sleep(1)
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, lambda: sync_method(*args, **kwargs))

    # async def llm_similarity(self):
    #     return await self.async_method_wrapper(self.sync_llm_similarity)
    #
    # def sync_llm_similarity(self):
    #     similarity_score = similarity_filter.calculate_similarity(self.expected, self.answer)
    #     llm_similarity = unethical_obj.evaluate_chain(self.expected, self.answer, self.model)
    #     return llm_similarity, similarity_score

    # change for custom metric
    async def feedback_custom_metrics(self):
        # results = []
        # for metric_name in enabled_custom_metrices:
        result = await self.async_method_wrapper(self.sync_process_custom_metrics)
        # results.append(result)
        print("Custom_Metric_Results---------\n\n\n", result)
        return result

    # def sync_process_custom_metrics(self):
    #     try:
    #         custom_metrices_obj = CustomMetrices()
    #         data = {
    #             'metric_name':"Coherence Scorer" ,
    #             'input': self.query,
    #             'output': self.answer,
    #             'context': self.context
    #         }
    #         result = custom_metrices_obj.process_custom_metrices(data)
    #         return result
    #     except Exception as e:
    #         import sys
    #         print('in error eval eng async custom metric function call', str(e), sys.exc_info()[-1].tb_lineno)
    #
    async def qc_relevance(self):
        return await self.async_method_wrapper(self.sync_qc_relevance)

    def sync_qc_relevance(self):
        start_time = 0
        end_time = 0
        # context_rel = openai.qs_relevance_with_cot_reasons(self.query, self.context)
        if self.model == "gpt-4o":
            start_time = time.time()
            response, reason, info = litellm.qs_relevance_with_cot_reasons(self.query, self.context)
            end_time = time.time()
        elif self.model == "Claude-V3":
            start_time = time.time()
            response, reason, info = litellmClaude.qs_relevance_with_cot_reasons(self.query, self.context)
            print("relevance\n\n\n")
            print("reason======\n\n\n", reason)
            print("\n\n\n\n")
            end_time = time.time()
        # answer_rel, reason, info = self.litellm.qs_relevance_with_cot_reasons_v2(self.query, self.context)
        # reason = context_rel[1]['reason'].split(':')[2].strip()
        self.latency += (end_time - start_time)
        cost = completion_cost(completion_response=info)
        self.totalcost += cost
        final_reason = reason['reason'].split(':')[2].strip()
        char_count, word_count = count_characters_and_words(final_reason)
        self.total_characters += char_count
        self.total_word += word_count
        latency = end_time - start_time
        tokens = info["usage"].get("total_tokens", 0)
        self.total_tokens += tokens
        return response, final_reason, cost, tokens, latency

    #
    # async def qs_relevance_v2(self):
    #     return await self.async_method_wrapper(self.sync_qs_relevance_v2)
    #
    # def sync_qs_relevance_v2(self):
    #     start_time = time.time()
    #     answer_rel, reason, info = self.litellm.qs_relevance_with_cot_reasons_v2(self.query, self.context)
    #     end_time = time.time()
    #     latency=end_time-start_time
    #     self.latency += (end_time - start_time)
    #     cost = completion_cost(completion_response=info)
    #     self.totalcost += cost
    #     tokens = info["usage"].get("total_tokens", 0)
    #     final_reason = reason['reason'].split(':')[2].strip()
    #     char_count, word_count = count_characters_and_words(final_reason)
    #     self.total_characters += char_count
    #     self.total_word += word_count
    #     return answer_rel, final_reason,cost,tokens,latency,word_count,char_count
    #     # context_rel = self.litellm.qs_relevance_with_cot_reasons_v2(self.query, self.context)
    #     # reason = context_rel[1]['reason'].split(':')[2].strip()
    #     # return context_rel[0], reason
    #
    async def qa_relevance(self):
        return await self.async_method_wrapper(self.sync_qa_relevance)

    def sync_qa_relevance(self):
        start_time = 0
        end_time = 0
        # answer_rel = openai.relevance_with_cot_reasons(self.query, self.answer)
        if (self.model == "gpt-4o"):
            start_time = time.time()
            answer_rel, reason, info = litellm.relevance_with_cot_reasons(self.query, self.answer)
            end_time = time.time()
        elif (self.model == "Claude-V3"):
            start_time = time.time()
            answer_rel, reason, info = litellmClaude.relevance_with_cot_reasons(self.query, self.answer)
            print("qarelevance\n\n\n")
            print("reason======\n\n\n", reason)
            print("\n\n\n\n")
            end_time = time.time()
        self.latency += (end_time - start_time)
        pair_latency = end_time - start_time
        print(
            f"Time taken for relevance calculation for this pair: {pair_latency:.2f} seconds")  # Log the time taken for each query-answer pair

        cost = completion_cost(completion_response=info)
        self.totalcost += cost
        final_reason = reason['reason'].split(':')[2].strip()
        char_count, word_count = count_characters_and_words(final_reason)
        self.total_characters += char_count
        self.total_word += word_count
        latency = end_time - start_time
        tokens = info["usage"].get("total_tokens", 0)
        self.total_tokens += tokens
        return answer_rel, final_reason, cost, tokens, latency, word_count, char_count

        # -----------------------------cove--------------------------------------------------------------------

    # async def cove(self):
    #     return await self.async_method_wrapper(self.sync_cove)
    #
    # def cove(self):
    #         result = cove_runner(self.model_type, self.query, self.answer)
    #         questions_count = result["verification_question"]
    #         answer_count = result["answer_count"]
    #         consistency_result = result["consistency_result"]
    #
    #         # Prepare the output based on consistency_result
    #         if consistency_result == 0:
    #             reason = f"Out of {questions_count} generated questions, {answer_count} are conflicting with the actual answer."
    #         else:
    #             reason = "The input answer is consistent."
    #
    #         return consistency_result, reason

    # async def cove(self):
    #     # Call the synchronous function within the async wrapper
    #     result = await self.async_method_wrapper(self.sync_cove)
    #
    #     questions_count = result["verification_question_count"]
    #     answer_count = result["inconsistent_count"]
    #     consistency_result = result["consistency_result"]
    #
    #     # Prepare the output based on consistency_result
    #     if consistency_result == 0:
    #         reason = f"Out of {questions_count} generated questions, {answer_count} are conflicting with the actual answer."
    #     else:
    #         reason = "The input answer is consistent."
    #
    #     return consistency_result, reason
    #
    # def sync_cove(self):
    #     # This is the synchronous function that performs the logic
    #     return cove_runner(self.model_type, self.query, self.answer)

    # async def cove(self):
    #     # Call the synchronous function within the async wrapper
    #     result = await self.async_method_wrapper(self.sync_cove)
    #
    #     questions_count = result["verification_question_count"]
    #     answer_count = result["inconsistent_count"]
    #     consistency_result = 0  # Initialize consistency_result
    #     verification_details = result.get("verification_details", [])  # Get the detailed verification results
    #
    #     # Calculate consistency_result based on the counts
    #     if questions_count > 0:
    #         consistent_count = questions_count - answer_count
    #         consistency_result = round(consistent_count / questions_count, 1)
    #
    #     # Prepare the output message
    #     if answer_count > 0:
    #         reason = (
    #                 f"Out of {questions_count} generated questions, {answer_count} are conflicting with the actual answer."
    #                 f"\n\nDetails of inconsistencies and consistencies mapped to specific question-answer pairs:\n"
    #                 + "\n\n".join([f"Q: {detail['sub_question']}\nA: {detail['sub_answer']}\n"
    #                                f"Status: {detail['status']}\nExplanation: {detail['explanation']}"
    #                                for detail in verification_details])
    #         )
    #     else:
    #         reason = (
    #                 "The input answer is consistent."
    #                 f"\n\nDetails of consistencies mapped to specific question-answer pairs:\n"
    #                 + "\n\n".join([f"Q: {detail['sub_question']}\nA: {detail['sub_answer']}\n"
    #                                f"Status: {detail['status']}\nExplanation: {detail['explanation']}"
    #                                for detail in verification_details])
    #         )
    #
    #     return consistency_result, reason, verification_details
    #
    # def sync_cove(self):
    #     # This is the synchronous function that performs the logic
    #     return cove_runner(self.model_type, self.query, self.answer)

    import json

    async def cove(self):
        # Call the synchronous function within the async wrapper
        result = await self.async_method_wrapper(self.sync_cove)

        questions_count = result["verification_question_count"]
        answer_count = result["inconsistent_count"]
        consistency_result = 0  # Initialize consistency_result
        verification_details = result.get("verification_details", [])  # Get the detailed verification results

        # Calculate consistency_result based on the counts
        if questions_count > 0:
            consistent_count = questions_count - answer_count
            consistency_result = round(consistent_count / questions_count, 1)

        # Prepare the reasons dictionary
        reasons = {}
        if answer_count > 0:
            reasons['message'] = (
                f"Out of {questions_count} generated questions, {answer_count} are conflicting with the actual answer."
            )
            reasons['details'] = [
                {
                    "question": detail['sub_question'],
                    "answer": detail['sub_answer'],
                    "status": detail['status'],
                    "explanation": detail['explanation']
                }
                for detail in verification_details
            ]
        else:
            reasons['message'] = "The input answer is consistent."
            reasons['details'] = [
                {
                    "question": detail['sub_question'],
                    "answer": detail['sub_answer'],
                    "status": detail['status'],
                    "explanation": detail['explanation']
                }
                for detail in verification_details
            ]

        # Return the consistency result and the reasons in JSON format
        return consistency_result, json.dumps(reasons)

    def sync_cove(self):
        # This is the synchronous function that performs the logic
        return cove_runner(self.model_type, self.query, self.answer)

    # async def cove(self):
    #     return await self.async_method_wrapper(self.sync_cove)
    # 
    # def sync_cove(self):
    #     start_time = time.time()
    # 
    #     # Use different model runners based on self.model
    #     if self.model == "gpt-4o":
    #         result = litellm.cove_runner(self.query, self.answer)
    #     elif self.model == "Claude-V3":
    #         result = litellmClaude.cove_runner(self.query, self.answer)
    #     else:
    #         raise ValueError("Unsupported model type")
    # 
    #     questions_count = result["verification_question"]
    #     answer_count = result["answer_count"]
    #     consistency_result = result["consistency_result"]
    # 
    #     # Prepare the output based on consistency_result
    #     if consistency_result == 0:
    #         reason = f"Out of {questions_count} generated questions, {answer_count} are conflicting with the actual answer."
    #     else:
    #         reason = "The input answer is consistent."
    # 
    #     end_time = time.time()
    # 
    #     # Log time taken for the cove calculation
    #     latency = end_time - start_time
    #     print(f"Time taken for cove calculation: {latency:.2f} seconds")
    # 
    #     # Update any necessary metrics
    #     self.latency += latency
    # 
    #     # Assuming there might be a cost associated with cove
    #     cost = completion_cost(completion_response=result)  # Adjust this based on your actual cost calculation
    #     self.totalcost += cost
    # 
    #     # Update total characters and words if applicable
    #     char_count, word_count = count_characters_and_words(reason)
    #     self.total_characters += char_count
    #     self.total_word += word_count
    # 
    #     return consistency_result, reason, cost, latency, word_count, char_count

    # ---------------------------------------------------------------------------------------------------
    #
    # async def groundedness(self):
    #     return await self.async_method_wrapper(self.sync_groundedness)
    #
    # def sync_groundedness(self):
    #     start_time = 0
    #     end_time = 0
    #     from trulens_eval.feedback import Groundedness
    #
    #     if (self.model == "Gpt-35-Exploration"):
    #         start_time = time.time()
    #         grounded = Groundedness(groundedness_provider=litellm)
    #         end_time =time.time()
    #     elif (self.model == "Claude-V3"):
    #         start_time = time.time()
    #         grounded = Groundedness(groundedness_provider=litellmClaude)
    #         end_time = time.time()
    #     self.latency+=(end_time-start_time)
    #     grounded_tuple,reason,info = grounded.groundedness_measure_with_cot_reasons(self.answer, self.context)
    #     print("grounded\n\n\n")
    #     print("reason======\n\n\n", reason)
    #     print("\n\n\n\n")
    #     cost = completion_cost(completion_response=info)
    #     self.totalcost+=cost
    #     # statement_score = list(grounded_tuple[0].values())
    #     statement_score = list(grounded_tuple.values())
    #     print("groundedness\n\n\n",grounded_tuple)
    #     supporting_statement=reason['reasons'].split(':')[2].strip()
    #     # supporting_statement = ':'.join(reason['reasons'].split(':')[2:]).strip()
    #     char_count, word_count = count_characters_and_words(supporting_statement)
    #     self.total_characters += char_count
    #     self.total_word += word_count
    #     latency = end_time - start_time
    #     tokens = info["usage"].get("total_tokens", 0)
    #     self.total_tokens += tokens
    #     return round(np.mean(statement_score), 1),supporting_statement,cost,tokens,latency,word_count,char_count
    #
    #
    #
    #
    # async def coherence(self):
    #     return await self.async_method_wrapper(self.sync_coherence)
    #
    # def sync_coherence(self):
    #     start_time = 0
    #     end_time = 0
    #     # coherence_with_cot_reason = openai.coherence_with_cot_reasons(self.answer)
    #     if (self.model == "Gpt-35-Exploration"):
    #         start_time=time.time()
    #         coherence_with_cot_reason,reason,info = litellm.coherence_with_cot_reasons(self.answer)
    #         end_time = time.time()
    #     elif (self.model == "Claude-V3"):
    #         start_time = time.time()
    #         coherence_with_cot_reason,reason,info = litellmClaude.coherence_with_cot_reasons(self.answer)
    #         print("coherence\n\n\n")
    #         print("reason======\n\n\n", reason)
    #         print("\n\n\n\n")
    #         end_time = time.time()
    #     self.latency+=(end_time-start_time)
    #     cost = completion_cost(completion_response=info)
    #     self.totalcost += cost
    #     final_reason = reason['reason'].split(':')[2].strip()
    #     char_count, word_count = count_characters_and_words(final_reason)
    #     self.total_characters += char_count
    #     self.total_word += word_count
    #     latency = end_time - start_time
    #     tokens = info["usage"].get("total_tokens", 0)
    #     self.total_tokens += tokens
    #     return coherence_with_cot_reason, final_reason,cost,tokens,latency,word_count,char_count
    #
    # async def summarization(self):
    #     return await self.async_method_wrapper(self.sync_summarization)
    #
    # def sync_summarization(self):
    #     start_time = 0
    #     end_time = 0
    #     # summarization = openai.comprehensiveness_with_cot_reasons(self.query, self.answer)
    #     if (self.model == "Gpt-35-Exploration"):
    #         start_time=time.time()
    #         summarization,reason,info = litellm.comprehensiveness_with_cot_reasons(self.query, self.answer)
    #         end_time=time.time()
    #     elif (self.model == "Claude-V3"):
    #         start_time=time.time()
    #         summarization,reason,info = litellmClaude.comprehensiveness_with_cot_reasons(self.query, self.answer)
    #         print("summarization\n\n\n")
    #         print("reason======\n\n\n", reason)
    #         print("\n\n\n\n")
    #         end_time=time.time()
    #     self.latency+=(end_time-start_time)
    #     cost = completion_cost(completion_response=info)
    #     self.totalcost += cost
    #     final_reason = reason['reason'].split(':')[2].strip()
    #     char_count, word_count = count_characters_and_words(final_reason)
    #     self.total_characters += char_count
    #     self.total_word += word_count
    #     latency = end_time - start_time
    #     tokens = info["usage"].get("total_tokens", 0)
    #     self.total_tokens += tokens
    #     return summarization, final_reason,cost,tokens,latency,word_count,char_count
    #
    # async def concisenses(self):
    #     return await self.async_method_wrapper(self.sync_concisenses)
    #
    # def sync_concisenses(self):
    #     start_time = 0
    #     end_time = 0
    #     # concisense = openai.conciseness_with_cot_reasons(self.answer)
    #     if (self.model == "Gpt-35-Exploration"):
    #         start_time = time.time()
    #         concisense, reason, info = litellm.conciseness_with_cot_reasons(self.answer)
    #         end_time = time.time()
    #     elif (self.model == "Claude-V3"):
    #         start_time = time.time()
    #         concisense, reason, info = litellmClaude.conciseness_with_cot_reasons(self.answer)
    #         print("conscisence\n\n\n")
    #         print("reason======\n\n\n", reason)
    #         print("\n\n\n\n")
    #         end_time = time.time()
    #     self.latency += (end_time - start_time)
    #     cost = completion_cost(completion_response=info)
    #     self.totalcost += cost
    #     final_reason = reason['reason'].split(':')[2].strip()
    #     char_count, word_count = count_characters_and_words(final_reason)
    #     self.total_characters += char_count
    #     self.total_word += word_count
    #     latency = end_time - start_time
    #     tokens = info["usage"].get("total_tokens", 0)
    #     self.total_tokens += tokens
    #     return concisense, final_reason, cost,tokens,latency,word_count,char_count
    #
    # async def controversiality_deprecated(self):
    #     return await self.async_method_wrapper(self.sync_controversiality_deprecated)
    #
    # def sync_controversiality_deprecated(self):
    #     start_time = 0
    #     end_time = 0
    #     # controversial = openai.controversiality_with_cot_reasons(self.answer)
    #     if (self.model == "Gpt-35-Exploration"):
    #         start_time=time.time()
    #         controversial,reason,info = litellm.controversiality_with_cot_reasons(self.answer)
    #         end_time=time.time()
    #     elif (self.model == "Claude-V3"):
    #         start_time=time.time()
    #         controversial,reason,info = litellmClaude.controversiality_with_cot_reasons(self.answer)
    #         print("controversial\n\n\n")
    #         print("reason======\n\n\n", reason)
    #         print("\n\n\n\n")
    #         end_time=time.time()
    #     self.latency+=(end_time-start_time)
    #     cost = completion_cost(completion_response=info)
    #     self.totalcost += cost
    #     final_reason = reason.get('reason', f"::{info['choices'][0]['message']['content']}").split(':')[2].strip()
    #     char_count, word_count = count_characters_and_words(final_reason)
    #     self.total_characters += char_count
    #     self.total_word += word_count
    #     latency = end_time - start_time
    #     tokens = info["usage"].get("total_tokens", 0)
    #     self.total_tokens += tokens
    #     return controversial, final_reason,cost,tokens,latency,word_count,char_count
    #
    # async def controversiality(self):
    #     return await self.async_method_wrapper(self.sync_controversiality)
    #
    # def sync_controversiality(self):
    #     start_time = time.time()
    #     controversial, reason, info = self.litellm.controversiality_with_cot_reasons_v2(self.answer)
    #     end_time = time.time()
    #     self.latency += (end_time - start_time)
    #     cost = completion_cost(completion_response=info)
    #     self.totalcost += cost
    #     final_reason = reason.get('reason', f"::{info['choices'][0]['message']['content']}").split(':')[2].strip()
    #     char_count, word_count = count_characters_and_words(final_reason)
    #     self.total_characters += char_count
    #     self.total_word += word_count
    #     latency = end_time - start_time
    #     tokens = info["usage"].get("total_tokens", 0)
    #     self.total_tokens += tokens
    #     return controversial, final_reason,cost,tokens,latency,word_count,char_count
    #
    # async def correctness(self):
    #     return await self.async_method_wrapper(self.sync_correctness)
    #
    # def sync_correctness(self):
    #     start_time = 0
    #     end_time = 0
    #     # correct_sc = openai.correctness_with_cot_reasons(self.answer)
    #     if (self.model == "Gpt-35-Exploration"):
    #         start_time=time.time()
    #         correct_sc,reason,info = litellm.correctness_with_cot_reasons(self.answer)
    #         end_time=time.time()
    #     elif (self.model == "Claude-V3"):
    #         start_time=time.time()
    #         correct_sc,reason,info = litellmClaude.correctness_with_cot_reasons(self.answer)
    #         print("correct_sc\n\n\n")
    #         print("reason======\n\n\n", reason)
    #         print("\n\n\n\n")
    #         end_time=time.time()
    #     self.latency+=(end_time-start_time)
    #     cost = completion_cost(completion_response=info)
    #     self.totalcost += cost
    #     final_reason = reason.get('reason', f"::{info['choices'][0]['message']['content']}").split(':')[2].strip()
    #     char_count, word_count = count_characters_and_words(final_reason)
    #     self.total_characters += char_count
    #     self.total_word += word_count
    #     latency = end_time - start_time
    #     tokens = info["usage"].get("total_tokens", 0)
    #     self.total_tokens += tokens
    #     return correct_sc, final_reason,cost,tokens,latency,word_count,char_count
    #
    # async def criminality(self):
    #     return await self.async_method_wrapper(self.sync_criminality)
    #
    # def sync_criminality(self):
    #     start_time = 0
    #     end_time = 0
    #     # criminal_sc = openai.criminality_with_cot_reasons(self.answer)
    #     if (self.model == "Gpt-35-Exploration"):
    #         start_time=time.time()
    #         criminal_sc,reason,info = litellm.criminality_with_cot_reasons(self.answer)
    #         end_time=time.time()
    #     elif (self.model == "Claude-V3"):
    #         start_time=time.time()
    #         criminal_sc,reason,info = litellmClaude.criminality_with_cot_reasons(self.answer)
    #         print("criminalsc\n\n\n")
    #         print("reason======\n\n\n", reason)
    #         print("\n\n\n\n")
    #         end_time=time.time()
    #     self.latency += (end_time - start_time)
    #     cost = completion_cost(completion_response=info)
    #     self.totalcost += cost
    #     final_reason = reason.get('reason', f"::{info['choices'][0]['message']['content']}").split(':')[2].strip()
    #     char_count, word_count = count_characters_and_words(final_reason)
    #     self.total_characters += char_count
    #     self.total_word += word_count
    #     latency = end_time - start_time
    #     tokens = info["usage"].get("total_tokens", 0)
    #     self.total_tokens += tokens
    #     return criminal_sc, final_reason,cost,tokens,latency,word_count,char_count
    #
    # async def harmfullness(self):
    #     return await self.async_method_wrapper(self.sync_harmfullness)
    #
    # def sync_harmfullness(self):
    #     start_time = 0
    #     end_time = 0
    #     # harmful = openai.harmfulness_with_cot_reasons(self.answer)
    #     if (self.model == "Gpt-35-Exploration"):
    #         start_time=time.time()
    #         harmful,reason,info = litellm.harmfulness_with_cot_reasons(self.answer)
    #         end_time=time.time()
    #     elif (self.model == "Claude-V3"):
    #         start_time=time.time()
    #         harmful,reason,info = litellmClaude.harmfulness_with_cot_reasons(self.answer)
    #         print("harmful\n\n\n")
    #         print("reason======\n\n\n", reason)
    #         print("\n\n\n\n")
    #         end_time=time.time()
    #     self.latency += (end_time - start_time)
    #     cost = completion_cost(completion_response=info)
    #     self.totalcost += cost
    #     final_reason = reason.get('reason', f"::{info['choices'][0]['message']['content']}").split(':')[2].strip()
    #     char_count, word_count = count_characters_and_words(final_reason)
    #     self.total_characters += char_count
    #     self.total_word += word_count
    #     latency = end_time - start_time
    #     tokens = info["usage"].get("total_tokens", 0)
    #     self.total_tokens += tokens
    #     return harmful, final_reason,cost,tokens,latency,word_count,char_count
    #
    # async def helpfulness(self):
    #     return await self.async_method_wrapper(self.sync_helpfulness)
    #
    # def sync_helpfulness(self):
    #     start_time = 0
    #     end_time = 0
    #     # helpful = openai.helpfulness_with_cot_reasons(self.answer)
    #     if (self.model == "Gpt-35-Exploration"):
    #         start_time=time.time()
    #         helpful,reason,info = litellm.helpfulness_with_cot_reasons(self.answer)
    #         end_time=time.time()
    #     elif (self.model == "Claude-V3"):
    #         start_time=time.time()
    #         helpful,reason,info = litellmClaude.helpfulness_with_cot_reasons(self.answer)
    #         print("harmfulness\n\n\n")
    #         print("reason======\n\n\n", reason)
    #         print("\n\n\n\n")
    #         end_time=time.time()
    #     self.latency+=(end_time-start_time)
    #     cost = completion_cost(completion_response=info)
    #     self.totalcost += cost
    #     final_reason = reason.get('reason', f"::{info['choices'][0]['message']['content']}").split(':')[2].strip()
    #     char_count, word_count = count_characters_and_words(final_reason)
    #     self.total_characters += char_count
    #     self.total_word += word_count
    #     latency = end_time - start_time
    #     tokens = info["usage"].get("total_tokens", 0)
    #     self.total_tokens += tokens
    #     return helpful, final_reason,cost,tokens,latency,word_count,char_count
    #
    # async def insensitivity(self):
    #     return await self.async_method_wrapper(self.sync_insensitivity)
    #
    # def sync_insensitivity(self):
    #     start_time = 0
    #     end_time = 0
    #     # insensitive = openai.insensitivity_with_cot_reasons(self.answer)
    #     if (self.model == "Gpt-35-Exploration"):
    #         start_time=time.time()
    #         insensitive,reason,info = litellm.insensitivity_with_cot_reasons(self.answer)
    #         end_time=time.time()
    #     elif (self.model == "Claude-V3"):
    #         start_time=time.time()
    #         insensitive,reason,info = litellmClaude.insensitivity_with_cot_reasons(self.answer)
    #         print("insensitive\n\n\n")
    #         print("reason======\n\n\n", reason)
    #         print("\n\n\n\n")
    #         end_time=time.time()
    #     self.latency += (end_time - start_time)
    #     cost = completion_cost(completion_response=info)
    #     self.totalcost += cost
    #     final_reason = reason.get('reason', f"::{info['choices'][0]['message']['content']}").split(':')[2].strip()
    #     char_count, word_count = count_characters_and_words(final_reason)
    #     self.total_characters += char_count
    #     self.total_word += word_count
    #     latency = end_time - start_time
    #     tokens = info["usage"].get("total_tokens", 0)
    #     self.total_tokens += tokens
    #     return insensitive, final_reason,cost,tokens,latency,word_count,char_count
    #
    # async def maliciousness(self):
    #     return await self.async_method_wrapper(self.sync_maliciousness)
    #
    # def sync_maliciousness(self):
    #     start_time = 0
    #     end_time = 0
    #     # malicious = openai.maliciousness_with_cot_reasons(self.answer)
    #     if (self.model == "Gpt-35-Exploration"):
    #         start_time=time.time()
    #         malicious,reason,info = litellm.maliciousness_with_cot_reasons(self.answer)
    #         end_time=time.time()
    #     elif (self.model == "Claude-V3"):
    #         start_time=time.time()
    #         malicious,reason,info = litellmClaude.maliciousness_with_cot_reasons(self.answer)
    #         print("malicious\n\n\n")
    #         print("reason======\n\n\n", reason)
    #         print("\n\n\n\n")
    #         end_time=time.time()
    #     self.latency += (end_time - start_time)
    #     cost = completion_cost(completion_response=info)
    #     self.totalcost += cost
    #     if not reason.get('reason'):
    #         print("No reason provided\n", f"Full response: {info['choices'][0]['message']['content']}")
    #     final_reason = reason.get('reason', f"::{info['choices'][0]['message']['content']}").split(':')[2].strip()
    #     char_count, word_count = count_characters_and_words(final_reason)
    #     self.total_characters += char_count
    #     self.total_word += word_count
    #     latency = end_time - start_time
    #     tokens = info["usage"].get("total_tokens", 0)
    #     self.total_tokens += tokens
    #     return malicious, final_reason,cost,tokens,latency,word_count,char_count
    #
    # async def misogyny_deprecated(self):
    #     return await self.async_method_wrapper(self.sync_misogyny_deprecated())
    #
    # def sync_misogyny_deprecated(self):
    #     start_time = 0
    #     end_time = 0
    #     # misogyny_sc = openai.misogyny_with_cot_reasons(self.answer)
    #     if (self.model == "Gpt-35-Exploration"):
    #         start_time=time.time()
    #         misogyny_sc,reason,info = litellm.misogyny_with_cot_reasons(self.answer)
    #         end_time=time.time()
    #     elif (self.model == "Claude-V3"):
    #         start_time=time.time()
    #         misogyny_sc,reason,info = litellmClaude.misogyny_with_cot_reasons(self.answer)
    #         print("misogyny\n\n\n")
    #         print("reason======\n\n\n", reason)
    #         print("\n\n\n\n")
    #         end_time=time.time()
    #     self.latency += (end_time - start_time)
    #     cost = completion_cost(completion_response=info)
    #     self.totalcost += cost
    #     final_reason = reason.get('reason', f"::{info['choices'][0]['message']['content']}").split(':')[2].strip()
    #     char_count, word_count = count_characters_and_words(final_reason)
    #     self.total_characters += char_count
    #     self.total_word += word_count
    #     latency = end_time - start_time
    #     tokens = info["usage"].get("total_tokens", 0)
    #     self.total_tokens += tokens
    #     return misogyny_sc, final_reason,cost,tokens,latency,word_count,char_count
    #
    # async def misogyny(self):
    #     return await self.async_method_wrapper(self.sync_misogyny)
    #
    # def sync_misogyny(self):
    #     start_time = time.time()
    #     misogyny_sc, reason, info = self.litellm.misogyny_with_cot_reasons_v2(self.answer)
    #     end_time = time.time()
    #     self.latency += (end_time - start_time)
    #     cost = completion_cost(completion_response=info)
    #     self.totalcost += cost
    #     if not reason.get('reason'):
    #         print("No reason provided\n", f"Full response: {info['choices'][0]['message']['content']}")
    #     final_reason = reason.get('reason', f"::{info['choices'][0]['message']['content']}").split(':')[2].strip()
    #     char_count, word_count = count_characters_and_words(final_reason)
    #     self.total_characters += char_count
    #     self.total_word += word_count
    #     latency = end_time - start_time
    #     tokens = info["usage"].get("total_tokens", 0)
    #     self.total_tokens += tokens
    #     return misogyny_sc, final_reason,cost,tokens,latency,word_count,char_count
    #
    # async def sentiment(self):
    #     return await self.async_method_wrapper(self.sync_sentiment)
    #
    # def sync_sentiment(self):
    #     start_time = 0
    #     end_time = 0
    #     # sentiment_sc = openai.sentiment_with_cot_reasons(self.answer)
    #     if (self.model == "Gpt-35-Exploration"):
    #         start_time=time.time()
    #         sentiment_sc,reason,info = litellm.sentiment_with_cot_reasons(self.answer)
    #         print("sentimentsc: ", sentiment_sc, reason)
    #         end_time=time.time()
    #     elif (self.model == "Claude-V3"):
    #         start_time=time.time()
    #         sentiment_sc,reason,info = litellmClaude.sentiment_with_cot_2reasons(self.answer)
    #         print("sentimentsc\n\n\n")
    #         print("reason======\n\n\n", reason)
    #         print("\n\n\n\n")
    #         end_time=time.time()
    #     self.latency += (end_time - start_time)
    #     cost = completion_cost(completion_response=info)
    #     self.totalcost += cost
    #     final_reason = reason.get('reason', "::No Reason Provided").split(':')[2].strip()
    #     char_count, word_count = count_characters_and_words(final_reason)
    #     self.total_characters += char_count
    #     self.total_word += word_count
    #     latency = end_time - start_time
    #     tokens = info["usage"].get("total_tokens", 0)
    #     self.total_tokens += tokens
    #     return sentiment_sc, final_reason,cost,tokens,latency,word_count,char_count
    #
    # async def stereotype(self):
    #     return await self.async_method_wrapper(self.sync_stereotype)
    #
    # def sync_stereotype(self):
    #     start_time = 0
    #     end_time = 0
    #     # stereotype_sc = openai.stereotypes_with_cot_reasons(self.query, self.answer)
    #     if (self.model == "Gpt-35-Exploration"):
    #         start_time=time.time()
    #         stereotype_sc,reason,info = litellm.stereotypes_with_cot_reasons(self.query, self.answer)
    #         end_time=time.time()
    #     elif (self.model == "Claude-V3"):
    #         start_time=time.time()
    #         stereotype_sc,reason,info= litellmClaude.stereotypes_with_cot_reasons(self.query, self.answer)
    #         print("stereotypesc\n\n\n")
    #         print("reason======\n\n\n", reason)
    #         print("\n\n\n\n")
    #         end_time=time.time()
    #     self.latency += (end_time - start_time)
    #     cost = completion_cost(completion_response=info)
    #     self.totalcost += cost
    #     if not reason.get('reason'):
    #         print("No reason provided\n", f"Full response: {info['choices'][0]['message']['content']}")
    #     final_reason = reason.get('reason', f"::Full response: {info['choices'][0]['message']['content']}").split(':')[2].strip()
    #     char_count, word_count = count_characters_and_words(final_reason)
    #     self.total_characters += char_count
    #     self.total_word += word_count
    #     latency = end_time - start_time
    #     tokens = info["usage"].get("total_tokens", 0)
    #     self.total_tokens += tokens
    #     return stereotype_sc, final_reason,cost,tokens,latency,word_count,char_count
    #
    # # async def pii_detection(self):
    # #     return await self.async_method_wrapper(self.sync_pii_detection)
    # #
    # # def sync_pii_detection(self):
    # #     pii = hug_provider.pii_detection_with_cot_reasons(self.answer)
    # #     reason = list(pii[1].keys())
    # #     time.sleep(1.5)
    # #     return round(1 - pii[0], 1), ";".join(reason)
    #
    # async def pii_detection(self):
    #     return await self.async_method_wrapper(self.sync_pii_detection)

    # def sync_pii_detection(self):
    #     # Use the pii_detector instance to analyze the answer text for PII
    #     start_time=time.time()
    #     pii_results = pii_detector.detect_pii(text=self.answer)
    #     end_time=time.time()
    #     self.latency+=(end_time-start_time)
    #
    #     # Check if any PII is detected
    #     if pii_results:
    #         score = round(1 - pii_results[0].score, 1)
    #         reason_str = "Detected PII"
    #     else:
    #         score = 0.0
    #         reason_str = "No PII detected"
    #
    #     time.sleep(1.5)
    #     # Return the score and reason string
    #     return score, reason_str

    # async def toxicity(self):
    #     return await self.async_method_wrapper(self.sync_toxicity)
    #
    # def sync_toxicity(self):
    #     start_time=time.time()
    #     toxic = hug_provider.toxic(self.answer)
    #     end_time=time.time()
    #     self.latency+=(end_time-start_time)
    #     time.sleep(1.5)
    #     return round(toxic, 1)

    # async def language_match(self):
    #     return await self.async_method_wrapper(self.sync_language_match)
    #
    # def sync_language_match(self):
    #     start_time=time.time()
    #     lan_match = hug_provider.language_match(self.query, self.answer)
    #     end_time=time.time()
    #     self.latency += (end_time - start_time)
    #     time.sleep(1.5)
    #     return round(lan_match[0], 1)

    async def factuality(self):
        return await self.async_method_wrapper(self.sync_factuality)

    def sync_factuality(self):
        start_time = time.time()
        factuality, reason, info = self.litellm.factuality_with_cot_reasons(self.context, self.answer)
        end_time = time.time()
        self.latency += (end_time - start_time)
        cost = completion_cost(completion_response=info)
        self.totalcost += cost
        statement_score = list(factuality.values())
        char_count, word_count = count_characters_and_words(reason["reasons"])
        self.total_characters += char_count
        self.total_word += word_count
        mean_score = round(np.mean(statement_score), 1)
        if np.isnan(mean_score):
            mean_score = 0
        print(mean_score, reason['reasons'], "\nfrom factuality")
        latency = end_time - start_time
        tokens = info["usage"].get("total_tokens", 0)
        self.total_tokens += tokens
        return mean_score, reason["reasons"], cost, tokens, latency, word_count, char_count

        # factuality_tuple = openai.factuality_with_cot_reasons(self.context, self.answer)
        # statement_score = list(factuality_tuple[0].values())
        # supporting_statement = factuality_tuple[1]
        # return round(np.mean(statement_score), 1), supporting_statement['reasons']

    async def coherence_qa(self):
        return await self.async_method_wrapper(self.sync_coherence_qa_v2)

    def sync_coherence_qa(self):
        start_time = time.time()
        coherence_sc, reason, info = self.litellm.coherence_with_cot_reasons_qa(self.query, self.answer)
        end_time = time.time()
        self.latency += (end_time - start_time)
        cost = completion_cost(completion_response=info)
        self.totalcost += cost
        final_reason = reason.get('reason', f"::{info['choices'][0]['message']['content']}").split(':')[2].strip()
        char_count, word_count = count_characters_and_words(final_reason)
        self.total_characters += char_count
        self.total_word += word_count
        latency = end_time - start_time
        tokens = info["usage"].get("total_tokens", 0)
        self.total_tokens += tokens
        return coherence_sc, final_reason, cost, tokens, latency, word_count, char_count
        # coherence_sc = openai.coherence_with_cot_reasons_qa(self.query, self.answer)
        # reason = coherence_sc[1]['reason'].split(':')[2].strip()
        # return coherence_sc[0], reason

    def sync_coherence_qa_v2(self):
        start_time = time.time()
        coherence_sc, reason, info = self.litellm.coherence_qa_v2(self.query, self.answer)
        end_time = time.time()
        self.latency += (end_time - start_time)
        cost = completion_cost(completion_response=info)
        self.totalcost += cost
        final_reason = reason.get('reason', f"::{info['choices'][0]['message']['content']}").split(':')[2].strip()
        char_count, word_count = count_characters_and_words(final_reason)
        self.total_characters += char_count
        self.total_word += word_count
        latency = end_time - start_time
        tokens = info["usage"].get("total_tokens", 0)
        self.total_tokens += tokens
        return coherence_sc, final_reason, f"${cost}", tokens, f"{latency} seconds"

    async def coherence_rejection(self):
        return await self.async_method_wrapper(self.sync_coherence_rejection)

    def sync_coherence_rejection(self):
        start_time = time.time()
        coherence_sc, reason, info = self.litellm.coherence_with_rejection(self.answer)
        end_time = time.time()
        self.latency += (end_time - start_time)
        cost = completion_cost(completion_response=info)
        self.totalcost += cost
        final_reason = reason.get('reason', f"::{info['choices'][0]['message']['content']}").split(':')[2].strip()
        char_count, word_count = count_characters_and_words(final_reason)
        self.total_characters += char_count
        self.total_word += word_count
        latency = end_time - start_time
        tokens = info["usage"].get("total_tokens", 0)
        self.total_tokens += tokens
        return coherence_sc, final_reason, cost, tokens, latency, word_count, char_count

        # coherence_sc = openai.coherence_with_rejection(self.answer)
        # reason = coherence_sc[1]['reason'].split(':')[2].strip()
        # return coherence_sc[0], reason

    async def fluency(self):
        return await self.async_method_wrapper(self.sync_fluency)

    def sync_fluency(self):
        start_time = time.time()
        fluency_sc, reason, info = self.litellm.fluency_with_cot_reasons(self.answer)
        end_time = time.time()
        self.latency += (end_time - start_time)
        cost = completion_cost(completion_response=info)
        self.totalcost += cost
        if not reason.get('reason'):
            print("No reason provided\n", f"Full response: {info['choices'][0]['message']['content']}")
        final_reason = reason.get('reason', f"::{info['choices'][0]['message']['content']}").split(':')[2].strip()
        char_count, word_count = count_characters_and_words(final_reason)
        self.total_characters += char_count
        self.total_word += word_count
        latency = end_time - start_time
        tokens = info["usage"].get("total_tokens", 0)
        self.total_tokens += tokens
        return fluency_sc, final_reason, cost, tokens, latency, word_count, char_count
        # coherence_sc = openai.fluency_with_cot_reasons(self.answer)
        # reason = coherence_sc[1]['reason'].split(':')[2].strip()
        # return coherence_sc[0], reason

    async def qs_ranking(self):
        return await self.async_method_wrapper(self.sync_qs_ranking)

    def sync_qs_ranking(self):
        try:
            if isinstance(self.context, list):
                context_list = self.context
            else:
                context_list = ast.literal_eval(self.context)
            verifications = []
            for context in context_list:
                start_time = time.time()
                verdict, info = self.litellm.qs_relevance_with_few_shot(self.query, context)
                end_time = time.time()
                self.latency += (end_time - start_time)
                cost = completion_cost(completion_response=info)
                self.totalcost += cost
                verifications.append(safe_json_loads(verdict))
            # verifications = [safe_json_loads(openai.qs_relevance_with_few_shot(self.query, context)) for context in context_list]
            response = [int("yes" in resp.get("verdict", " ").lower()) if resp.get("verdict") else np.nan for resp in
                        verifications]
            denominator = sum(response) + 1e-10
            numerator = sum([(sum(response[: i + 1]) / (i + 1)) * response[i] for i in range(len(response))])
            score = numerator / denominator
            reason = [', '.join([f"{key}: {value}" for key, value in res.items()]) for res in verifications]
            char_count, word_count = count_characters_and_words(reason)
            self.total_characters += char_count
            self.total_word += word_count
            latency = end_time - start_time
            tokens = info["usage"].get("total_tokens", 0)
            self.total_tokens += tokens
            return score, '\n'.join(reason), cost, tokens, latency, word_count, char_count
        except Exception as e:
            print(e)
            return -1, "Failed to run"

    # async def llm_controversiality(self):
    #     return await self.async_method_wrapper(self.sync_llm_controversiality)
    #
    # def sync_llm_controversiality(self):
    #     return llm_contoversiality(self.query)

    # async def profanity(self):
    #     return await self.async_method_wrapper(self.sync_profanity)
    #
    # def sync_profanity(self):
    #     result=predict_negative_prompts(self.answer)
    #     bool_unethical =result["is_unethical"]
    #     ans=-1
    #     if(bool_unethical=="true"):
    #         ans=1
    #     else:
    #         ans=0
    #
    #     reasons="\n".join(result["reasons"])
    #     return ans,reasons
    #
    # async def cove(self):
    #     return await self.async_method_wrapper(self.sync_cove)
    #
    # def sync_cove(self):
    #     result=cove(self.answer)
    #     reasons = "\n".join([str(item) for item in result["inconsistent_answers"]])
    #     return result["inconsistency_score"],reasons

    async def cosine_similarity(self):
        return await self.async_method_wrapper(self.sync_cosine_similarity)

    def sync_cosine_similarity(self):
        result = calculate_context_relevance(self.query, self.answer)
        print("______________cosine\n", result)

        if result and isinstance(result[0][0], float):  # Access the first element (score) in the first tuple
            score = result[0][0]  # This is the similarity score
            reason = result[0][1]  # This is the reason for the score
            return score, reason
        else:
            return None

    # async def is_unethical(self):
    #   return await self.async_method_wrapper(self.sync_is_unethical)
    #
    # def sync_is_unethical(self):
    #  score,reason=harmfulness_detector(self.answer)
    #  return score,reason
    #
    # async def professionalism(self):
    #     return await self.async_method_wrapper(self.sync_professionalism)
    #
    # def sync_professionalism(self):
    #     score,reason = professionalism(self.answer)
    #
    #     return score,reason

    # -----------------------------------------------------------------------------------------
    async def f1_score(self):
        return await self.async_method_wrapper(self.sync_f1_score)

    def sync_f1_score(self):
        f1, reason = f1_score(self.answer, self.expected)
        return f1, reason

    async def bleu(self):
        return await self.async_method_wrapper(self.sync_bleu)

    def sync_bleu(self):
        score, reason = bleu(self.answer, self.expected)
        return score, reason

    async def rouge_1(self):
        return await self.async_method_wrapper(self.sync_rouge_1)

    def sync_rouge_1(self):
        rouge = ROUGE()
        scores, reason = rouge.rouge_1(self.answer, self.expected)
        return scores, reason

    async def rouge_2(self):
        return await self.async_method_wrapper(self.sync_rouge_2)

    def sync_rouge_2(self):
        rouge = ROUGE()
        scores, reason = rouge.rouge_2(self.answer, self.expected)
        return scores, reason

    async def rouge_l(self):
        return await self.async_method_wrapper(self.sync_rouge_l)

    def sync_rouge_l(self):
        rouge = ROUGE()
        scores, reason = rouge.rouge_l(self.answer, self.expected)
        return scores, reason

    # async def meteor_score(self):
    #         return await self.async_method_wrapper(self.sync_meteor_score)

    #     def sync_meteor_score(self):
    #         meteor = METEOR()
    #         score, reason = meteor.meteor_score(self.answer, self.context)
    #         return score, reason
    #
    async def hallucination(self):
        return await self.async_method_wrapper(self.sync_hallucination)

    def sync_hallucination(self):
        hallu = hallucination(self.query, self.answer, self.context)
        score, reason = hallu.execute_qa_process()
        return score, reason
#
# #     ---------------------------------------------------------------------------------------------
#
#     async def jailbreak(self):
#         return await self.async_method_wrapper(self.sync_jailbreak)
#
#     def sync_jailbreak(self):
#         if config['JAILBREAK_FLAG']:
#             config['JAILBREAK_FLAG'] = False
#             return baseobj.jailbreak(self.usecase, self.no_of_templates)
#
#     async def adversarial_attack(self):
#         return await self.sync_adversarial_attack()
#
#     async def sync_adversarial_attack(self):
#         if config['ADVERSARIAL_ATTACK_FLAG']:
#             config['ADVERSARIAL_ATTACK_FLAG'] = False
#             return await baseobj.adversarial_attack(self.prompt)
#
#     async def red_teaming(self):
#         return await self.async_method_wrapper(self.sync_red_teaming)
#
#     def sync_red_teaming(self):
#         if config['RED_TEAMING_FLAG']:
#             config['RED_TEAMING_FLAG'] = False
#             return baseobj.red_teaming(self.testcase, self.additional_context)
