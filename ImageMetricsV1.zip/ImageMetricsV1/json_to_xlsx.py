import json
import pandas as pd

# Load JSON data from file
with open('eval_results.json', 'r') as file:
    json_data = json.load(file)

# Convert JSON data to DataFrame
records = []
for item in json_data:
    prompt = item["prompt"]
    image_url = item["image_url"]
    for analyzer, result in item["results"].items():
        record = {
            "prompt": prompt,
            "image_url": image_url,
            "analyzer": analyzer,
            "score": result.get("score", ""),
            "reason": result.get("reason", ""),
            "co-ordinates": result.get("co-ordinates", ""),
            "recommendations": result.get("recommendations", ""),
            "status": result.get("relevance", result.get("hallucination_contradiction", False))
        }
        records.append(record)

df = pd.DataFrame(records)

# Save DataFrame to Excel
df.to_excel("eval_results.xlsx", index=False)

print("The evaluation results have been successfully saved to eval_results.xlsx.")
