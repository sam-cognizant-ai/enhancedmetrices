import requests
from PIL import Image, ImageDraw
from io import BytesIO


def highlight_coordinates(image_url, coordinates):
    try:
        # Download the image
        response = requests.get(image_url)
        response.raise_for_status()  # Check if the request was successful
        img = Image.open(BytesIO(response.content))
        draw = ImageDraw.Draw(img)

        # Get image dimensions
        image_width, image_height = img.size

        # Iterate over each set of coordinates
        for coord in coordinates:
            x_min, y_min, width, height = coord
            x_max = x_min + width
            y_max = y_min + height

            # Adjust y_min and y_max to account for the bottom-left origin
            y_min_adjusted = image_height - y_min - height
            y_max_adjusted = image_height - y_min

            # Ensure coordinates are within image bounds
            if 0 <= x_min < image_width and 0 <= x_max <= image_width and 0 <= y_min_adjusted < image_height and 0 <= y_max_adjusted <= image_height:
                # Draw a rectangle with red color
                draw.rectangle([(x_min, y_min_adjusted), (x_max, y_max_adjusted)], outline="red", width=2)
            else:
                print(f"Coordinates {coord} are out of image bounds.")

        # Save the image with highlighted coordinates
        img.save("highlighted_image.png")
        print("The image with highlighted coordinates is saved as 'highlighted_image.png'.")
    except requests.RequestException as e:
        print(f"Error downloading the image: {e}")
    except Exception as e:
        print(f"An error occurred: {e}")


# Example usage
image_url = "https://qafastest.cognizant.com/fastestLiteFiles/sreesuryas-genai-testing/images/mysogynistic.jpg"  # Replace with the URL to your image file
coordinates = [(850, 700), 150, 300]  # Replace with your coordinates

highlight_coordinates(image_url, coordinates)
