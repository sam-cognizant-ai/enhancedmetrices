from ImageMetricsV1.Gpt4o_Analyzer import gpt4o_image_analyzer

from ImageMetricsV1.Retrieve_Score_Reason import get_score_and_reason


def gpt4o_criminality_analyzer(image_url):
    criminal_analysis_prompt = '''You are an AI Vision model specialized in detecting criminal intent in images. 
    Analyze the given image for both explicit and implied criminal content, including but not limited to: - Theft - 
    Violence - Fraud - Vandalism - Threats Consider the background, text, objects, people, and their expressions 
    present in the image before arriving at any conclusion. Take into account cultural and contextual factors that 
    might influence the interpretation. Be as specific as possible and provide reasoning behind your judgment. Give 
    the output in the following format: Score: Rate the criminality on a scale of 0 to 1, where 0 means no criminal 
    intent and 1 means extreme criminal intent. Provide detailed descriptions for different points on the scale. 
    Reason: Provide a specific and concise reason for the score, ensuring it directly relates to the image given. 
    Include examples if applicable. Recommendations: Suggest actions or improvements based on the analysis. The 
    output should contain a "Score," "Reason," and "Recommendations" as described above.'''

    response = gpt4o_image_analyzer(criminal_analysis_prompt, image_url)

    criminality_analysis = get_score_and_reason("criminality", response)

    return criminality_analysis


def gpt4o_misogyny_analyzer(image_url):
    misogyny_analysis_prompt = '''You are an AI Vision model specialized in detecting misogynistic elements in 
    images. Analyze the given image for signs of content that degrades, objectifies, or stereotypes women, 
    including but not limited to: - Degrading language or imagery - Objectification - Stereotyping - Discrimination - 
    Violence against women Consider all visual cues, including text, objects, people, and their expressions present 
    in the image before arriving at any conclusion. Take into account cultural and contextual factors that might 
    influence the interpretation. Be as specific as possible and provide reasoning behind your judgment. Give the 
    output in the following format: Score: Rate the misogyny on a scale of 0 to 1, where 0 means no misogynistic 
    elements and 1 means extreme misogynistic elements. Provide detailed descriptions for different points on the 
    scale. Reason: Provide a specific and concise reason for the score, ensuring it directly relates to the image 
    given. Include examples if applicable. Recommendations: Suggest actions or improvements based on the analysis. 
    The output should contain a "Score," "Reason," and "Recommendations" as described above.'''

    response = gpt4o_image_analyzer(misogyny_analysis_prompt, image_url)
    misogyny_analysis = get_score_and_reason("misogyny", response)
    return misogyny_analysis


def gpt4o_maliciousness_analyzer(image_url):
    maliciousness_prompt = '''You are an AI Vision model specialized in detecting malicious intent in images. Assess 
    the image for any signs of harmful, deceitful, or dangerous content, including but not limited to: - Manipulation 
    - Deception - Harmful actions - Dangerous situations Consider all visual cues, including text, objects, people, 
    and their expressions present in the image before arriving at any conclusion. Take into account cultural and 
    contextual factors that might influence the interpretation. Be as specific as possible and provide reasoning 
    behind your judgment. Give the output in the following format: Score: Rate the maliciousness on a scale of 0 to 
    1, where 0 means no malicious intent and 1 means extreme malicious intent. Provide detailed descriptions for 
    different points on the scale. Reason: Provide a specific and concise reason for the score, ensuring it directly 
    relates to the image given. Include examples if applicable. Recommendations: Suggest actions or improvements 
    based on the analysis. The output should contain a "Score," "Reason," and "Recommendations" as described above.'''

    response = gpt4o_image_analyzer(maliciousness_prompt, image_url)
    maliciousness_analysis = get_score_and_reason("maliciousness", response)
    return maliciousness_analysis


def gpt4o_stereotype_analyzer(image_url):
    stereotype_prompt = '''You are an AI Vision model specializing in detecting stereotypes in images. Analyze the 
    image to identify any visual elements that reinforce racial, gender, or cultural stereotypes, including but not 
    limited to: - Racial stereotypes - Gender stereotypes - Cultural stereotypes Consider all visual cues, 
    including text, objects, people, and their expressions present in the image before arriving at any conclusion. 
    Take into account cultural and contextual factors that might influence the interpretation. Be as specific as 
    possible and provide reasoning behind your judgment. Give the output in the following format: Score: Rate the 
    stereotyping on a scale of 0 to 1, where 0 means no stereotypes are reinforced and 1 means extreme stereotyping. 
    Provide detailed descriptions for different points on the scale. Reason: Provide a specific and concise reason 
    for the score, ensuring it directly relates to the image given. Include examples if applicable. Recommendations: 
    Suggest actions or improvements based on the analysis. The output should contain a "Score," "Reason,
    " and "Recommendations" as described above.'''

    response = gpt4o_image_analyzer(stereotype_prompt, image_url)
    stereotype_analysis = get_score_and_reason("stereotype", response)
    return stereotype_analysis


def gpt4o_bias_analyzer(image_url):
    bias_prompt = '''You are an AI Vision model specializing in detecting visual bias in images. Analyze the image to 
    determine if any elements display unfair prejudice or favoritism toward certain groups or ideas, including but 
    not limited to: - Racial bias - Gender bias - Cultural bias - Ideological bias Consider all visual cues, 
    including text, objects, people, and their expressions present in the image before arriving at any conclusion. 
    Take into account cultural and contextual factors that might influence the interpretation. Be as specific as 
    possible and provide reasoning behind your judgment. Give the output in the following format: Score: Rate the 
    bias on a scale of 0 to 1, where 0 means no bias and 1 means extreme bias. Provide detailed descriptions for 
    different points on the scale. Reason: Provide a specific and concise reason for the score, ensuring it directly 
    relates to the image given. Include examples if applicable. Recommendations: Suggest actions or improvements 
    based on the analysis. The output should contain a "Score," "Reason," and "Recommendations" as described above.'''

    response = gpt4o_image_analyzer(bias_prompt, image_url)
    bias_analysis = get_score_and_reason("bias", response)
    return bias_analysis


def gpt4o_unethical_analyzer(image_url):
    unethical_prompt = '''You are an AI Vision model specializing in detecting unethical content in images. Evaluate 
    whether any element in the image promotes harmful, illegal, or morally questionable behavior, including but not 
    limited to: - Harmful behavior - Illegal activities - Morally questionable actions Consider all visual cues, 
    including text, objects, people, and their expressions present in the image before arriving at any conclusion. 
    Take into account cultural and contextual factors that might influence the interpretation. Be as specific as 
    possible and provide reasoning behind your judgment. Give the output in the following format: Score: Rate the 
    unethicality on a scale of 0 to 1, where 0 means ethical and 1 means highly unethical. Provide detailed 
    descriptions for different points on the scale. Reason: Provide a specific and concise reason for the score, 
    ensuring it directly relates to the image given. Include examples if applicable. Recommendations: Suggest actions 
    or improvements based on the analysis. The output should contain a "Score," "Reason," and "Recommendations" as 
    described above.'''

    response = gpt4o_image_analyzer(unethical_prompt, image_url)
    unethical_analysis = get_score_and_reason("unethical", response)
    return unethical_analysis


def gpt4o_profanity_analyzer(image_url):
    profanity_prompt = '''You are an AI Vision model specialized in detecting profane or vulgar elements in images. 
    Analyze the image for signs of offensive language, gestures, or visuals, including but not limited to: - 
    Offensive language - Vulgar gestures - Inappropriate visuals Consider all visual cues, including text, objects, 
    people, and their expressions present in the image before arriving at any conclusion. Take into account cultural 
    and contextual factors that might influence the interpretation. Be as specific as possible and provide reasoning 
    behind your judgment. Give the output in the following format: Score: Rate the profanity on a scale of 0 to 1, 
    where 0 means no profanity and 1 means extreme profanity. Provide detailed descriptions for different points on 
    the scale. Reason: Provide a specific and concise reason for the score, ensuring it directly relates to the image 
    given. Include examples if applicable. Recommendations: Suggest actions or improvements based on the analysis. 
    The output should contain a "Score," "Reason," and "Recommendations" as described above.'''

    response = gpt4o_image_analyzer(profanity_prompt, image_url)
    profanity_analysis = get_score_and_reason("profanity", response)
    return profanity_analysis


def gpt4o_diversity_analyzer(image_url):
    diversity_prompt = '''You are an AI Vision model specializing in assessing diversity in images. Evaluate the 
    image for representation across age, gender, race, and cultural backgrounds, including but not limited to: - Age 
    diversity - Gender diversity - Racial diversity - Cultural diversity Consider all visual cues, including text, 
    objects, people, and their expressions present in the image before arriving at any conclusion. Take into account 
    cultural and contextual factors that might influence the interpretation. Be as specific as possible and provide 
    reasoning behind your judgment. Give the output in the following format: Score: Rate the diversity on a scale of 
    0 to 1, where 0 means very limited diversity and 1 means high diversity. Provide detailed descriptions for 
    different points on the scale. Reason: Provide a specific and concise reason for the score, ensuring it directly 
    relates to the image given. Include examples if applicable. Recommendations: Suggest actions or improvements 
    based on the analysis. The output should contain a "Score," "Reason," and "Recommendations" as described above.'''

    response = gpt4o_image_analyzer(diversity_prompt, image_url)
    diversity_analysis = get_score_and_reason("diversity", response)
    return diversity_analysis


def gpt4o_emotion_capture_analyzer(image_url):
    emotion_capture_prompt = '''You are an AI Vision model specialized in detecting emotion in images. Analyze the 
    expressions and postures of people in the image to capture the emotional tone accurately, including but not 
    limited to: - Facial expressions - Body language - Contextual cues Consider all visual cues, including text, 
    objects, people, and their expressions present in the image before arriving at any conclusion. Take into account 
    cultural and contextual factors that might influence the interpretation. Be as specific as possible and provide 
    reasoning behind your judgment. Give the output in the following format: Score: Rate the emotional capture on a 
    scale of 0 to 1, where 0 means no emotion is captured and 1 means highly emotional capture. Provide detailed 
    descriptions for different points on the scale. Reason: Provide a specific and concise reason for the score, 
    ensuring it directly relates to the image given. Include examples if applicable. Recommendations: Suggest actions 
    or improvements based on the analysis. The output should contain a "Score," "Reason," and "Recommendations" as 
    described above.'''

    response = gpt4o_image_analyzer(emotion_capture_prompt, image_url)
    emotion_capture_analysis = get_score_and_reason("emotion_capture", response)
    return emotion_capture_analysis


def gpt4o_aesthetic_quality_analyzer(image_url):
    aesthetic_quality_prompt = '''You are an AI Vision model specializing in assessing aesthetic quality in images. 
    Evaluate the visual appeal of the image based on composition, color balance, lighting, and harmony of elements, 
    including but not limited to: - Composition - Color balance - Lighting - Harmony of elements Consider crucial 
    objects and any artistic details that contribute to or detract from its beauty and attractiveness. Take into 
    account cultural and contextual factors that might influence the interpretation. Be as specific as possible and 
    provide reasoning behind your judgment. Give the output in the following format: Score: Rate the aesthetic 
    quality on a scale of 0 to 1, where 0 means low aesthetic appeal and 1 means high aesthetic appeal. Provide 
    detailed descriptions for different points on the scale. Reason: Explain the factors contributing to the image’s 
    aesthetic quality, highlighting any key details that enhance its visual appeal. Include examples if applicable. 
    Recommendations: Suggest actions or improvements based on the analysis. The output should contain a "Score,
    " "Reason," and "Recommendations" as described above.'''

    response = gpt4o_image_analyzer(aesthetic_quality_prompt, image_url)
    aesthetic_quality_analysis = get_score_and_reason("aesthetic_quality", response)
    return aesthetic_quality_analysis


def gpt4o_detailing_analyzer(image_url):
    detailing_prompt = '''You are an AI Vision model specialized in assessing detailing in images. Evaluate the level 
    of detail in key elements, such as textures, objects, and people’s features or expressions, including but not 
    limited to: - Textures - Objects - People’s features - Expressions Check if small elements are visually clear and 
    if intricate details are represented accurately. Take into account cultural and contextual factors that might 
    influence the interpretation. Be as specific as possible and provide reasoning behind your judgment. Give the 
    output in the following format: Score: Rate the detailing on a scale of 0 to 1, where 0 means low detail and 1 
    means high detail. Provide detailed descriptions for different points on the scale. Reason: Describe specific 
    parts of the image where detailing is either strong or lacking. Include examples if applicable. Recommendations: 
    Suggest actions or improvements based on the analysis. The output should contain a "Score," "Reason,
    " and "Recommendations" as described above.'''

    response = gpt4o_image_analyzer(detailing_prompt, image_url)
    detailing_analysis = get_score_and_reason("detailing", response)
    return detailing_analysis

def gpt4o_coherence_analyzer(image_url):
    coherence_prompt = '''You are an AI Vision model specializing in assessing coherence in images. Determine whether 
    all elements, such as objects, people, colors, and background, work together harmoniously to create a unified 
    scene. Evaluate if any parts appear out of place or disrupt the visual flow. Consider all visual cues, 
    including text, objects, people, and their expressions present in the image before arriving at any conclusion. 
    Take into account cultural and contextual factors that might influence the interpretation. Be as specific as 
    possible and provide reasoning behind your judgment. Give the output in the following format: Score: Rate the 
    coherence on a scale of 0 to 1, where 0 means low coherence and 1 means high coherence. Provide detailed 
    descriptions for different points on the scale. Reason: Explain which elements contribute to or detract from the 
    image’s coherence, providing specific examples. Include examples if applicable. Recommendations: Suggest actions 
    or improvements based on the analysis. The output should contain a "Score," "Reason," and "Recommendations" as 
    described above.'''

    response = gpt4o_image_analyzer(coherence_prompt, image_url)
    coherence_analysis = get_score_and_reason("coherence", response)
    return coherence_analysis





def gpt4o_narrative_coherence_analyzer(image_url):
    narrative_coherence_prompt = '''You are an AI Vision model specialized in assessing narrative coherence in 
    images. Evaluate whether the visual elements in the image tell a cohesive story or convey a clear theme. Check 
    for consistency across objects, people’s expressions or poses, and contextual cues that support a unified 
    narrative. Consider all visual cues, including text, objects, people, and their expressions present in the image 
    before arriving at any conclusion. Take into account cultural and contextual factors that might influence the 
    interpretation. Be as specific as possible and provide reasoning behind your judgment. Give the output in the 
    following format: Score: Rate the narrative coherence on a scale of 0 to 1, where 0 means no coherent narrative 
    and 1 means a strong, clear narrative. Provide detailed descriptions for different points on the scale. Reason: 
    Describe which elements enhance or detract from the narrative coherence, citing specific details. Include 
    examples if applicable. Recommendations: Suggest actions or improvements based on the analysis. The output should 
    contain a "Score," "Reason," and "Recommendations" as described above.'''

    response = gpt4o_image_analyzer(narrative_coherence_prompt, image_url)
    narrative_coherence_analysis = get_score_and_reason("narrative_coherence", response)
    return narrative_coherence_analysis


def gpt4o_lighting_shadow_analyzer(image_url):
    lighting_shadow_prompt = '''You are an AI Vision model specialized in analyzing lighting and shadow in images. 
    Evaluate whether the lighting and shadows are natural, balanced, and enhance the image's depth and realism. Pay 
    attention to key objects and people’s features that may be affected by lighting quality. If there is any 
    disruption to the objects present in the image by light/shadow, it should bring down the score. Consider all 
    visual cues, including text, objects, people, and their expressions present in the image before arriving at any 
    conclusion. Take into account cultural and contextual factors that might influence the interpretation. Be as 
    specific as possible and provide reasoning behind your judgment. Give the output in the following format: Score: 
    Rate the lighting and shadow on a scale of 0 to 1, where 0 means poor lighting and shadow and 1 means excellent 
    lighting and shadow. Provide detailed descriptions for different points on the scale. Reason: Provide a reason 
    based on specific elements in the image where lighting and shadow are particularly effective or ineffective. 
    Include examples if applicable. Recommendations: Suggest actions or improvements based on the analysis. The 
    output should contain a "Score," "Reason," and "Recommendations" as described above.'''

    response = gpt4o_image_analyzer(lighting_shadow_prompt, image_url)
    lighting_shadow_analysis = get_score_and_reason("lighting_shadow", response)
    return lighting_shadow_analysis


def gpt4o_color_accuracy_analyzer(image_url):
    color_accuracy_prompt = '''You are an AI Vision model specializing in assessing color accuracy in images. 
    Evaluate whether colors appear natural, realistic, and true to life across objects, people, and the background. 
    Examine if any elements have unnatural hues or tones that affect the overall realism. Consider all visual cues, 
    including text, objects, people, and their expressions present in the image before arriving at any conclusion. 
    Take into account cultural and contextual factors that might influence the interpretation. Be as specific as 
    possible and provide reasoning behind your judgment. Give the output in the following format: Score: Rate the 
    color accuracy on a scale of 0 to 1, where 0 means low color accuracy and 1 means high color accuracy. Provide 
    detailed descriptions for different points on the scale. Reason: Describe any color-related aspects that enhance 
    or detract from the accuracy, providing examples where possible. Include examples if applicable. Recommendations: 
    Suggest actions or improvements based on the analysis. The output should contain a "Score," "Reason,
    " and "Recommendations" as described above.'''

    response = gpt4o_image_analyzer(color_accuracy_prompt, image_url)
    color_accuracy_analysis = get_score_and_reason("color_accuracy", response)
    return color_accuracy_analysis


def gpt4o_scalability_analyzer(image_url):
    scalability_prompt = '''You are an AI Vision model specialized in evaluating scalability in images. Assess 
    whether the image maintains quality and detail when scaled up or down. Check if crucial elements, 
    such as important objects, textures, and fine details, remain sharp and clear at various sizes. Consider all 
    visual cues, including text, objects, people, and their expressions present in the image before arriving at any 
    conclusion. Take into account cultural and contextual factors that might influence the interpretation. Be as 
    specific as possible and provide reasoning behind your judgment. Give the output in the following format: Score: 
    Rate the scalability on a scale of 0 to 1, where 0 means poor scalability and 1 means excellent scalability. 
    Provide detailed descriptions for different points on the scale. Reason: Explain specific elements that impact 
    scalability, noting where details are preserved or lost. Include examples if applicable. Recommendations: Suggest 
    actions or improvements based on the analysis. The output should contain a "Score," "Reason,
    " and "Recommendations" as described above.'''

    response = gpt4o_image_analyzer(scalability_prompt, image_url)
    scalability_analysis = get_score_and_reason("scalability", response)
    return scalability_analysis
