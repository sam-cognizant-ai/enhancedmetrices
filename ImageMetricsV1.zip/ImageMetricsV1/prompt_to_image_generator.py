# import os
# import openai
# from PIL import Image
# import requests
# from io import BytesIO
# import logging
# from tqdm import tqdm
#
# # Configuration management using environment variables
# api_base = os.getenv("API_BASE", "https://llmexplorationgpt4o.openai.azure.com/")
# api_key = os.getenv("API_KEY", "f5c173e7b5a8445894254e9e703ebc30")  # Replace with your API key
# deployment_name = os.getenv("DEPLOYMENT_NAME", "tcoegpt4o")
# api_version = os.getenv("API_VERSION", "2024-02-15-preview")
#
# # Set up OpenAI API client
# openai.api_key = api_key
# openai.api_base = api_base
# openai.deployment_name = deployment_name
# openai.api_version = api_version
#
#
# # Set up logging
# logging.basicConfig(level=logging.INFO)
#
#
# def generate_image_from_prompt(prompt, n=1, size="1024x1024"):
#     try:
#         # Generate image(s) using OpenAI API
#         response = openai.Image.create(
#             prompt=prompt,
#             n=n,
#             size=size
#         )
#
#         # List to store image objects
#         images = []
#
#         # Download images
#         for i in tqdm(range(n), desc="Downloading images"):
#             image_url = response['data'][i]['url']
#             image_response = requests.get(image_url)
#             image_response.raise_for_status()  # Check for HTTP errors
#             img = Image.open(BytesIO(image_response.content))
#             images.append(img)
#
#         return images
#
#     except Exception as e:
#         logging.error(f"Error generating image: {e}")
#         return []
#
#
# def main():
#     # User inputs for the prompt and number of images
#     prompt = input("Enter your prompt: ")
#     num_images = int(input("Enter the number of images to generate (default is 1): ") or 1)
#
#     # Validate prompt
#     if not prompt:
#         logging.error("Prompt cannot be empty.")
#         return
#
#     # Generate images based on the prompt
#     images = generate_image_from_prompt(prompt, n=num_images)
#
#     # If images are generated, show and save them
#     if images:
#         for idx, image in enumerate(images):
#             image.show()
#             image_save_path = f"generated_image_{idx + 1}.png"
#             image.save(image_save_path)
#             logging.info(f"Image saved to {image_save_path}")
#     else:
#         logging.error("Failed to generate images.")
#
#
# if __name__ == "__main__":
#     main()


import os
import openai
from PIL import Image
import requests
from io import BytesIO
import logging
from tqdm import tqdm

# Configuration management using environment variables
api_base = os.getenv("API_BASE", "https://llmexplorationgpt4o.openai.azure.com/")
api_key = os.getenv("API_KEY", "f5c173e7b5a8445894254e9e703ebc30")  # Replace with your API key
deployment_name = os.getenv("DEPLOYMENT_NAME", "tcoegpt4o")
api_version = os.getenv("API_VERSION", "2024-02-15-preview")

# Set up OpenAI API client
openai.api_key = api_key
openai.api_base = api_base
openai.deployment_name = deployment_name
openai.api_version = api_version

# Set up logging
logging.basicConfig(level=logging.INFO)


def generate_image_from_prompt(prompt, n=1, size="1024x1024"):
    try:
        # Generate image(s) using OpenAI API
        response = openai.Image.create_variation(
            prompt=prompt,
            n=n,
            size=size
        )

        # List to store image objects
        images = []

        # Download images
        for i in tqdm(range(n), desc="Downloading images"):
            image_url = response['data'][i]['url']
            image_response = requests.get(image_url)
            image_response.raise_for_status()  # Check for HTTP errors
            img = Image.open(BytesIO(image_response.content))
            images.append(img)

        return images

    except Exception as e:
        logging.error(f"Error generating image: {e}")
        return []


def main():
    # User inputs for the prompt and number of images
    prompt = input("Enter your prompt: ")
    num_images = int(input("Enter the number of images to generate (default is 1): ") or 1)

    # Validate prompt
    if not prompt:
        logging.error("Prompt cannot be empty.")
        return

    # Generate images based on the prompt
    images = generate_image_from_prompt(prompt, n=num_images)

    # If images are generated, show and save them
    if images:
        for idx, image in enumerate(images):
            image.show()
            image_save_path = f"generated_image_{idx + 1}.png"
            image.save(image_save_path)
            logging.info(f"Image saved to {image_save_path}")
    else:
        logging.error("Failed to generate images.")


if __name__ == "__main__":
    main()
