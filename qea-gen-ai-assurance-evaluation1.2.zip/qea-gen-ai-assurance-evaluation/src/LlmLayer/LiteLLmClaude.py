import boto3
from litellm import completion

class LiteLLMClaude:
    def __init__(self):
        pass

    bedrock = boto3.client(
                service_name="bedrock-runtime",
                region_name="us-east-1",
                aws_access_key_id="AKIAZAQCHAM5JXRY7TFG",
                aws_secret_access_key="AWSSECRETACCESSKEY",
    )

    response = completion(
                model='bedrock/anthropic.claude-3-haiku-20240307-v1:0',
                messages=[{ "content": "Write a poem on tree","role": "user"}],
                aws_bedrock_client=bedrock,
    )

    print("Output::::",response)
    if 'choices' in response and len(response['choices']) > 0:
        answer = response['choices'][0].get('message', {}).get('content', '')
        print("answer:\n",answer)
    else:
        print("None")