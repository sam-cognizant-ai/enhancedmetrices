from ImageMetricsV1.Gpt4o_Analyzer import gpt4o_image_analyzer
from ImageMetricsV1.Retrieve_Score_Reason import get_score_and_reason

import requests
import io
from PIL import Image


def gpt4o_relevance_analyzer(user_image_prompt, user_image_url):
    relevance_prompt = f'''
                                    You are given an image and a prompt.
                                    Prompt: {user_image_prompt}.
                                    Ensure the image aligns with the above prompt and doesn't deviate from it. Check if it includes all the objects specified in the prompt along with the specified color, shape, size, and alignment.
                                    The explanation or objects or text data present in the prompt should be present in the image as specified by the user and should not divert from the prompt.
                                    Based on the above explanation, assess the image with the prompt and give back a score and a reason.
                                    Be as specific as possible and provide reasoning behind your judgment.
                                    The persons in the image can be in any position.
                                    If more than one expression is provided in the prompt for the same person, then consider even if the person gives a neutral expression.
                                    If no distinct facial expression is assigned to one person, then consider the neutral expression shown on their face.
                                    If the positioning of body parts is not mentioned in the prompt, then do not reduce the score for it and any positioning of their body parts can be considered.
                                    If the user prompt holds words such as drugs, etc., that are classified as illegal under law, then the image should not be generated.

                                    Give the output in the following format:
                                    Score: Rate the relevance on a scale of 0 to 1, where 0 means no relevance with the prompt and 0 must be given if the image is generated for the prompt which contains illegal words under the law such as drugs, and 1 means the image is relevant with the specifications such as color, shape, size, and alignment of people and objects mentioned in the prompt.
                                    Reason: Be specific and concise in the reason provided and make sure it is not deviated from the image given.
                                    Recommendations: Suggest actions or improvements based on the analysis.
                                    The output should contain a "Score," "Reason," and "Recommendations" as described above.
                                '''

    response = gpt4o_image_analyzer(relevance_prompt, user_image_url)

    relevance_result = get_score_and_reason("relevance", response)

    return relevance_result


def gpt4o_hallucination_contradiction_analyzer(user_image_prompt, user_image_url):
    hallucination_contradiction_prompt = f'''
                                    You are an AI Vision model specialized in identifying hallucinating contradictions in images.
                                    You are given an image and a prompt.
                                    Prompt: {user_image_prompt}.
                                    Evaluate whether there are any objects or depictions in the image that contradict the primary goal as specified in the prompt.
                                    Consider the following principles: If the prompt outlines specific objects, actions, or scenarios, check if these are accurately represented in the image or if there are any elements that create confusion or misrepresentation.
                                    Only analyze aspects that are explicitly mentioned in the prompt, avoiding any assumptions.

                                    Give the output in the following format:
                                    Score: Rate the level of contradiction or hallucination on a scale of 0 to 1, where 0 means there are significant contradictions or hallucinations present, and 1 means the image aligns perfectly with the specified goal.
                                    Reason: Provide a brief explanation of your assessment, closely referencing the details visible in the image and how they relate to the prompt, particularly focusing on any contradictory elements that may undermine the primary goal.
                                    Recommendations: Suggest actions or improvements based on the analysis.
                                    The output should contain a "Score," "Reason," and "Recommendations" as described above.
                                '''

    response = gpt4o_image_analyzer(hallucination_contradiction_prompt, user_image_url)
    hallucination_contradiction_analysis = get_score_and_reason("hallucination_contradiction", response)
    return hallucination_contradiction_analysis


def gpt4o_hallucination_factual_analyzer(user_image_prompt, user_image_url):
    hallucination_factuality_prompt = f'''
                                    You are an AI Vision model specialized in evaluating the factuality and relevance of images in relation to a given prompt.
                                    You are given an image and a prompt.
                                    Prompt: {user_image_prompt}.
                                    Assess whether there are any objects, depictions, or background elements in the image that diminish the weightage of what is specified in the prompt.
                                    The image may or may not contain the elements described in the prompt, but if the size, prominence, or focus on backgrounds, objects, or other humans overshadows the primary goal specified in the prompt, it should be noted.
                                    Only analyze aspects that are explicitly mentioned in the prompt, avoiding any assumptions.

                                    Give the output in the following format:
                                    Score: Rate the level of distraction or dilution of focus on a scale of 0 to 1, where 0 means the image significantly undermines the primary goal, and 1 means it effectively supports the primary goal without distractions.
                                    Reason: Provide a brief explanation of your assessment, closely referencing the details visible in the image and how they relate to the prompt, particularly noting any elements that reduce the emphasis on the intended focus.
                                    Recommendations: Suggest actions or improvements based on the analysis.
                                    The output should contain a "Score," "Reason," and "Recommendations" as described above.
                                '''

    response = gpt4o_image_analyzer(hallucination_factuality_prompt, user_image_url)
    hallucination_factual_analysis = get_score_and_reason("hallucination_factuality", response)
    return hallucination_factual_analysis


def gpt4o_instruction_analyzer(user_image_prompt, user_image_url):
    instruction_prompt = f'''
                                    You are an AI Vision model specialized in assessing compliance with specified instructions in images.
                                    You are given an image and a prompt.
                                    Prompt: {user_image_prompt}.
                                    Evaluate whether the image adheres to the instructions outlined in the prompt, including any to-do's, mandatory information, and not-to-do's.
                                    Consider the following principles: If the prompt specifies required elements or actions, check for their presence and correctness in the image.
                                    Similarly, identify any elements that contradict the instructions or should not be included based on the prompt.
                                    Only analyze aspects that are explicitly mentioned in the prompt, avoiding any assumptions.

                                    Give the output in the following format:
                                    Score: Rate the level of compliance with the instructions on a scale of 0 to 1, where 0 means the image fails to adhere to the specified instructions, and 1 means it fully complies without any omissions or contradictions.
                                    Reason: Provide a brief explanation of your assessment, closely referencing the details visible in the image and how they align with the instructions in the prompt, highlighting any areas of compliance or non-compliance.
                                    Recommendations: Suggest actions or improvements based on the analysis.
                                    The output should contain a "Score," "Reason," and "Recommendations" as described above.
                                '''

    response = gpt4o_image_analyzer(instruction_prompt, user_image_url)
    instruction_analysis = get_score_and_reason("instruction_analysis", response)
    return instruction_analysis


def gpt4o_object_match_analyzer(user_image_prompt, user_image_url):
    r = requests.get(user_image_url, stream=True)
    image = Image.open(io.BytesIO(r.content))

    # image.show()

    image_width = image.width
    image_height = image.height

    print("--- width x height :::: ", image_width, image_height)

    object_match_prompt = f'''
                                    You are an AI Vision model specialized in verifying the presence and characteristics of objects in images.
                                    You are given an image and a prompt.
                                    Prompt: {user_image_prompt}.
                                    Evaluate whether the objects or entities mentioned in the prompt are present in the image, ensuring to map them properly, including their color, orientation, and position.
                                    If any specified objects are missing from the image, list them explicitly.
                                    Consider the following principles: For each object, human(s) or elements, if mentioned in the prompt, check if it is accurately depicted in terms of its visual characteristics as outlined.
                                    Only analyze aspects that are explicitly mentioned in the prompt, avoiding any assumptions.

                                    Co-ordinates: Provide the coordinates in the format: [(x_min, y_min), width, height] - Each set of coordinates should be enclosed in parentheses and formatted specifically for use in Python.
                                    Image Dimensions:
                                    - The image width is {image_width}px and height is {image_height}px.
                                    - The coordinate system origin (0, 0) is located at the bottom-left corner of the image.
                                    - X-axis: Starts from the bottom-left and runs from 0 to {image_width}.
                                    - Y-axis: Starts from the bottom-left and runs from 0 to {image_height}.

                                    Output Requirements for co-ordinates:
                                    - For each detected violation, output the coordinates of a bounding rectangle that precisely encloses the area of the violation.
                                    - Each set of coordinates should be in the format [(x_min, y_min), width, height], where:
                                    - `x_min` and `y_min` specify the bottom-left corner of the rectangle,
                                    - `width` is the length of the rectangle along the X-axis,
                                    - `height` is the length of the rectangle along the Y-axis.
                                    - Only mark the borders of the necessary elements, and avoid including any surrounding areas.
                                    - If multiple violations are detected, provide a separate set of coordinates for each one.
                                    Example Output for co-ordinates: [(x_min1, y_min1), width1, height1] [(x_min2, y_min2), width2, height2] ...

                                    Give the output in the following format:
                                    Score: Rate the accuracy of the object match on a scale of 0 to 1, where 0 means there are significant discrepancies or missing elements, and 1 means all specified objects are accurately represented.
                                    Reason: Provide a detailed explanation of your assessment, closely referencing the details visible in the image, including the characteristics of matched objects, and explicitly listing any objects mentioned in the prompt that are absent from the image.
                                    Co-ordinates: Provide the coordinates of potential places in the specified format where a violation has been found.
                                    Recommendations: Suggest actions or improvements based on the analysis.
                                    The output should contain a "Score," "Reason," "Co-ordinates," and "Recommendations" as described above.
                                '''

    response = gpt4o_image_analyzer(object_match_prompt, user_image_url)
    object_match_analysis = get_score_and_reason("object_match", response)
    return object_match_analysis


def gpt4o_interpretability_analyzer(user_image_prompt, user_image_url):
    interpretability_prompt = f'''
                                    You are an AI Vision model specialized in assessing interpretability in images.
                                    You are given an image and a prompt.
                                    Prompt: {user_image_prompt}.
                                    Assess whether the image content is clear and easy to understand at a glance as specified in the prompt.
                                    Extract the elements/objects present in the prompt and check if the elements/objects present in the prompt are given high importance.
                                    Pay attention to objects, people, and their expressions or gestures, as well as the overall organization of elements, to judge if viewers can quickly grasp the main theme or message as specified in the prompt.
                                    Only analyze aspects that are explicitly mentioned in the prompt, avoiding any assumptions.

                                    Give the output in the following format:
                                    Score: Rate interpretability on a scale of 0 to 1, where 0 means very difficult to interpret and 1 means highly interpretable.
                                    Reason: Provide specific examples of elements that enhance or detract from the image’s interpretability.
                                    Recommendations: Suggest actions or improvements based on the analysis.
                                    The output should contain a "Score," "Reason," and "Recommendations" as described above.
                                '''

    response = gpt4o_image_analyzer(interpretability_prompt, user_image_url)
    interpretability_analysis = get_score_and_reason("interpretability", response)
    return interpretability_analysis


def gpt4o_clarity_analyzer(user_image_prompt, user_image_url):
    clarity_prompt = f'''
                                    You are an AI Vision model specializing in evaluating clarity in images based on the prompt.
                                    Prompt: {user_image_prompt}.
                                    Assess whether all key elements, such as important objects, faces, and background details that are present in the prompt are sharp, well-defined, and free from visual distortions or blurriness.
                                    If there is any hindrance to the clarity of the objects, reduce the score.

                                    Give the output in the following format:
                                    Score: Rate clarity on a scale of 0 to 1, where 0 means very unclear and 1 means highly clear.
                                    Reason: Provide a brief explanation on areas where clarity is strong or lacking, mentioning specific elements.
                                    Recommendations: Suggest actions or improvements based on the analysis.
                                    The output should contain a "Score," "Reason," and "Recommendations" as described above.
                                '''

    response = gpt4o_image_analyzer(clarity_prompt, user_image_url)
    clarity_analysis = get_score_and_reason("clarity", response)
    return clarity_analysis


def gpt4o_sentiment_analyzer(user_image_prompt, user_image_url):
    sentiment_analysis_result_prompt = f'''
                                    You are an AI Vision model specialized in detecting sentiment present in images.
                                    Consider the prompt when calculating the sentiment.
                                    Prompt: {user_image_prompt}.
                                    Analyze the given image for its sentiment. Also make sure to consider the background, text, and objects present in the image.
                                    If people or animals are present in the image, make sure to analyze their expressions.
                                    Be as specific as possible and provide reasoning behind your judgment.
                                    Consider the emotions to be positive, negative, and neutral.

                                    Give the output in the following format:
                                    Score: Rate the sentiment of the image on a scale of 0 to 1, where 0 means negative sentiment and 1 means positive sentiment.
                                    Reason: Be specific and concise in the reason provided and make sure it is not deviated from the image given.
                                    Recommendations: Suggest actions or improvements based on the analysis.
                                    The output should contain a "Score," "Reason," and "Recommendations" as described above.
                                '''

    response = gpt4o_image_analyzer(sentiment_analysis_result_prompt, user_image_url)

    sentiment_analysis_result = get_score_and_reason("sentiment", response=response)

    return sentiment_analysis_result



