# from ImageMetricsV1.Image_single_prompt_metrics_updated import (
#     gpt4o_criminality_analyzer, gpt4o_misogyny_analyzer, gpt4o_maliciousness_analyzer, gpt4o_stereotype_analyzer,
#     gpt4o_bias_analyzer, gpt4o_unethical_analyzer, gpt4o_profanity_analyzer, gpt4o_diversity_analyzer,
#     gpt4o_emotion_capture_analyzer, gpt4o_aesthetic_quality_analyzer, gpt4o_detailing_analyzer,
#     gpt4o_scalability_analyzer,
#     gpt4o_color_accuracy_analyzer, gpt4o_narrative_coherence_analyzer, gpt4o_coherence_analyzer,
#     gpt4o_lighting_shadow_analyzer
# )
# from ImageMetricsV1.Image_User_Prompt_Analyzer_updated import (
#     gpt4o_relevance_analyzer, gpt4o_hallucination_contradiction_analyzer, gpt4o_hallucination_factual_analyzer,
#     gpt4o_instruction_analyzer, gpt4o_object_match_analyzer, gpt4o_interpretability_analyzer, gpt4o_clarity_analyzer,
#     gpt4o_sentiment_analyzer
# )
# import inspect
#
#
# def analyze_image(prompts_images):
#     for item in prompts_images:
#         prompt = item.get("prompt", "")
#         image_url = item.get("image_url", "")
#
#         if not image_url.strip():
#             print("Having an image_url is mandatory to proceed")
#             continue
#
#         if prompt.strip():
#             print("We have both prompt and image")
#             analyzers = [
#                 gpt4o_relevance_analyzer, gpt4o_hallucination_contradiction_analyzer,
#                 gpt4o_hallucination_factual_analyzer,
#                 gpt4o_instruction_analyzer, gpt4o_object_match_analyzer, gpt4o_interpretability_analyzer,
#                 gpt4o_clarity_analyzer,
#                 gpt4o_sentiment_analyzer,
#                 gpt4o_criminality_analyzer, gpt4o_misogyny_analyzer, gpt4o_maliciousness_analyzer,
#                 gpt4o_stereotype_analyzer,
#                 gpt4o_bias_analyzer, gpt4o_unethical_analyzer, gpt4o_profanity_analyzer, gpt4o_diversity_analyzer,
#                 gpt4o_emotion_capture_analyzer, gpt4o_aesthetic_quality_analyzer, gpt4o_detailing_analyzer,
#                 gpt4o_coherence_analyzer,
#                 gpt4o_narrative_coherence_analyzer, gpt4o_lighting_shadow_analyzer, gpt4o_color_accuracy_analyzer,
#                 gpt4o_scalability_analyzer
#             ]
#         else:
#             print("We only have image..")
#             analyzers = [
#                 gpt4o_criminality_analyzer, gpt4o_misogyny_analyzer, gpt4o_maliciousness_analyzer,
#                 gpt4o_stereotype_analyzer,
#                 gpt4o_bias_analyzer, gpt4o_unethical_analyzer, gpt4o_profanity_analyzer, gpt4o_diversity_analyzer,
#                 gpt4o_emotion_capture_analyzer, gpt4o_aesthetic_quality_analyzer, gpt4o_detailing_analyzer,
#                 gpt4o_coherence_analyzer,
#                 gpt4o_narrative_coherence_analyzer, gpt4o_lighting_shadow_analyzer, gpt4o_color_accuracy_analyzer,
#                 gpt4o_scalability_analyzer
#             ]
#
#         for analyzer in analyzers:
#             if len(inspect.signature(analyzer).parameters) == 2:
#                 result = analyzer(prompt, image_url)
#             else:
#                 result = analyzer(image_url)
#             print(f"{analyzer.__name__}: {result}")
#
#
# if __name__ == '__main__':
#     response_objs = [
#         {
#             "prompt": "Image of a woman getting robbed while a person is threatening her with a knife",
#             "image_url": "https://qafastest.cognizant.com/fastestLiteFiles/sreesuryas-genai-testing/images/robbing_woman.png"
#         },
#         {
#             "image_url": "https://qafastest.cognizant.com/fastestLiteFiles/sreesuryas-genai-testing/images/mysogynistic.jpg",
#         }
#     ]
#
#     analyze_image(response_objs)

#-------------------------------------------------------------------------------------------------------

# import json
# from ImageMetricsV1.Image_single_prompt_metrics_updated import (
#     gpt4o_criminality_analyzer, gpt4o_misogyny_analyzer, gpt4o_maliciousness_analyzer, gpt4o_stereotype_analyzer,
#     gpt4o_bias_analyzer, gpt4o_unethical_analyzer, gpt4o_profanity_analyzer, gpt4o_diversity_analyzer,
#     gpt4o_emotion_capture_analyzer, gpt4o_aesthetic_quality_analyzer, gpt4o_detailing_analyzer,
#     gpt4o_scalability_analyzer,
#     gpt4o_color_accuracy_analyzer, gpt4o_narrative_coherence_analyzer, gpt4o_coherence_analyzer,
#     gpt4o_lighting_shadow_analyzer
# )
# from ImageMetricsV1.Image_User_Prompt_Analyzer_updated import (
#     gpt4o_relevance_analyzer, gpt4o_hallucination_contradiction_analyzer, gpt4o_hallucination_factual_analyzer,
#     gpt4o_instruction_analyzer, gpt4o_object_match_analyzer, gpt4o_interpretability_analyzer, gpt4o_clarity_analyzer,
#     gpt4o_sentiment_analyzer
# )
# import inspect
#
#
# def analyze_image(prompts_images):
#     for item in prompts_images:
#         prompt = item.get("prompt", "")
#         image_url = item.get("image_url", "")
#
#         if not prompt.strip() or not image_url.strip():
#             print("Both prompt and image_url are mandatory to proceed")
#             continue
#
#         print("We have both prompt and image")
#         analyzers = [
#             gpt4o_relevance_analyzer, gpt4o_hallucination_contradiction_analyzer,
#             gpt4o_hallucination_factual_analyzer,
#             gpt4o_instruction_analyzer, gpt4o_object_match_analyzer, gpt4o_interpretability_analyzer,
#             gpt4o_clarity_analyzer,
#             gpt4o_sentiment_analyzer,
#             gpt4o_criminality_analyzer, gpt4o_misogyny_analyzer, gpt4o_maliciousness_analyzer,
#             gpt4o_stereotype_analyzer,
#             gpt4o_bias_analyzer, gpt4o_unethical_analyzer, gpt4o_profanity_analyzer, gpt4o_diversity_analyzer,
#             gpt4o_emotion_capture_analyzer, gpt4o_aesthetic_quality_analyzer, gpt4o_detailing_analyzer,
#             gpt4o_coherence_analyzer,
#             gpt4o_narrative_coherence_analyzer, gpt4o_lighting_shadow_analyzer, gpt4o_color_accuracy_analyzer,
#             gpt4o_scalability_analyzer
#         ]
#
#         for analyzer in analyzers:
#             if len(inspect.signature(analyzer).parameters) == 2:
#                 result = analyzer(prompt, image_url)
#             else:
#                 result = analyzer(image_url)
#             print(f"{analyzer.__name__}: {result}")
#
#
# if __name__ == '__main__':
#     with open('response_objs.json', 'r') as file:
#         response_objs = json.load(file)
#
#     analyze_image(response_objs)

#-------------------------------------------------------------------------------------------------------

import json
from ImageMetricsV1.Image_single_prompt_metrics_updated import (
    gpt4o_criminality_analyzer, gpt4o_misogyny_analyzer, gpt4o_maliciousness_analyzer, gpt4o_stereotype_analyzer,
    gpt4o_bias_analyzer, gpt4o_unethical_analyzer, gpt4o_profanity_analyzer, gpt4o_diversity_analyzer,
    gpt4o_emotion_capture_analyzer, gpt4o_aesthetic_quality_analyzer, gpt4o_detailing_analyzer,
    gpt4o_scalability_analyzer,
    gpt4o_color_accuracy_analyzer, gpt4o_narrative_coherence_analyzer, gpt4o_coherence_analyzer,
    gpt4o_lighting_shadow_analyzer
)
from ImageMetricsV1.Image_User_Prompt_Analyzer_updated import (
    gpt4o_relevance_analyzer, gpt4o_hallucination_contradiction_analyzer, gpt4o_hallucination_factual_analyzer,
    gpt4o_instruction_analyzer, gpt4o_object_match_analyzer, gpt4o_interpretability_analyzer, gpt4o_clarity_analyzer,
    gpt4o_sentiment_analyzer
)
import inspect


def analyze_image(prompts_images, output_file):
    results = []

    for item in prompts_images:
        prompt = item.get("prompt", "")
        image_url = item.get("image_url", "")

        if not prompt.strip() or not image_url.strip():
            print("Both prompt and image_url are mandatory to proceed")
            continue

        print("We have both prompt and image")
        analyzers = [
            gpt4o_relevance_analyzer, gpt4o_hallucination_contradiction_analyzer,
            gpt4o_hallucination_factual_analyzer,
            gpt4o_instruction_analyzer, gpt4o_object_match_analyzer, gpt4o_interpretability_analyzer,
            gpt4o_clarity_analyzer,
            gpt4o_sentiment_analyzer,
            gpt4o_criminality_analyzer, gpt4o_misogyny_analyzer, gpt4o_maliciousness_analyzer,
            gpt4o_stereotype_analyzer,
            gpt4o_bias_analyzer, gpt4o_unethical_analyzer, gpt4o_profanity_analyzer, gpt4o_diversity_analyzer,
            gpt4o_emotion_capture_analyzer, gpt4o_aesthetic_quality_analyzer, gpt4o_detailing_analyzer,
            gpt4o_coherence_analyzer,
            gpt4o_narrative_coherence_analyzer, gpt4o_lighting_shadow_analyzer, gpt4o_color_accuracy_analyzer,
            gpt4o_scalability_analyzer
        ]

        item_results = {"prompt": prompt, "image_url": image_url, "results": {}}

        for analyzer in analyzers:
            if len(inspect.signature(analyzer).parameters) == 2:
                result = analyzer(prompt, image_url)
            else:
                result = analyzer(image_url)
            item_results["results"][analyzer.__name__] = result
            print(f"{analyzer.__name__}: {result}")

        results.append(item_results)

        # Write the current result to the JSON file
        with open(output_file, 'w') as file:
            json.dump(results, file, indent=4)


if __name__ == '__main__':
    with open('response_objs.json', 'r') as file:
        response_objs = json.load(file)

    analyze_image(response_objs, 'eval_results.json')




