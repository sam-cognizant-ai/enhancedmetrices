# truncation = True
# padding = 'longest'
# max_length = 60
# return_tensors = "pt"
# num_beams = 5
# num_return_sequences = 5
# temperature = 1.5
# skip_special_tokens = True
# similarity_score = 75
# AZURE_OPENAI_API_KEY = "AZUREOPENAIAPIKEY"
# AZURE_OPENAI_ENDPOINT = "https://exploregenaiworkspace.openai.azure.com"
# promptInput = "I want to book a flight"
# OPENAI_API_VERSION = "2023-03-15-preview"
# HUGGINGFACE_API_KEY = "HUGGINGFACEAPIKEY"
# Deployment_Name="gpt35exploration"
# WHYLABS_DEFAULT_ORG_ID = "org-XM9vYv"
# WHYLABS_DEFAULT_DATASET_ID = "model-11"
# WHYLABS_API_KEY = " "
# OPENAI_API_KEY = "AZUREOPENAIAPIKEY"
# MODEL_ENGINE = "gpt-35-turbo"
# # Claude Credentials
# SERVICE_NAME = "bedrock-runtime"
# REGION_NAME = "us-east-1"
# AWS_ACCESS_KEY_ID = "AKIAZAQCHAM5JXRY7TFG"
# AWS_SECRET_ACCESS_KEY = "AWSSECRETACCESSKEY"
#
#
# # ADVERSARIAL ATTACK <START>
# ADVERSARIAL_ATTACK_NO_OF_RESPONSES = 2
# ADVERSARIAL_ATTACK_PROMPT_MIN_SCORE = 0.8
# ADVERSARIAL_ATTACK_PROMPT_RESPONSE_MIN_SCORE = 0.5
#
# AI_BOT_URL = "http://127.0.0.1:5001/hospital_chat"
#
# # RED TEAMING <START>
# # PYTHON_COMPILER_3_10_URL = r"C:\Users\QEACHNFSTDEVTM\AppData\Local\Programs\Python\Python310\python.exe"
# PYTHON_COMPILER_3_10_URL = r"C:\WINDOWS\system32\env3.10\Scripts\python.exe"
# RED_TEAM_PYRIT_URL = r""
# # RED TEAMING <END>
#
# config = {
#     'JAILBREAK_FLAG': False,
#     'ADVERSARIAL_ATTACK_FLAG': False,
#     'RED_TEAMING_FLAG': False
# }
#
# # Unstructured API key and URL
# UNSTRUCTURED_API_KEY = ""
# UNSTRUCTURED_API_URL = ''

truncation = True
padding = 'longest'
max_length = 60
return_tensors = "pt"
num_beams = 5
num_return_sequences = 5
temperature = 1.5
skip_special_tokens = True
similarity_score = 75
AZURE_OPENAI_API_KEY = "58108d2bc56c4bc0825662a669dcd5e8"
AZURE_OPENAI_ENDPOINT = "https://mktg-service-azure-gpt.openai.azure.com/"
promptInput = "I want to book a flight"
OPENAI_API_VERSION = "2024-02-15-preview"
HUGGINGFACE_API_KEY = "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"
Deployment_Name = "mktg-gpt-4-omni"
WHYLABS_DEFAULT_ORG_ID = "org-XM9vYv"
WHYLABS_DEFAULT_DATASET_ID = "model-11"
WHYLABS_API_KEY = "KReVmApa89.trDaK6TTs16BoVezKCMl77r3zPbfZrgL3LkmCSxinnfj6CcToFeE0:org-XM9vYv"
OPENAI_API_KEY = "58108d2bc56c4bc0825662a669dcd5e8"
MODEL_ENGINE = "mktg-gpt-4-omni"
# Claude Credentials
SERVICE_NAME = "bedrock-runtime"
REGION_NAME = "us-east-1"
AWS_ACCESS_KEY_ID = "AKIAZAQCHAM5JXRY7TFG"
AWS_SECRET_ACCESS_KEY = "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"

#app-endpoint config
BASE_URL = "https://mktgaisrch-py-test.victoriouspond-0d0c0c3f.eastus.azurecontainerapps.io"
QUESTION = "How can Cognizant help my business grow?"
CLIENT_ID = "M2JhNWY1YjNiYTU2OWVmNGJiZDgxNDM4N2I2MmQ0NjY="
CLIENT_SECRET = "MWY0MGRkNjcyMDZlOWExMTY0MjdjZjEzZmQ5NTA1MDAwODQ5MDM4MzAwYjY1N2E0YmUxN2RjY2I1NmMzMzlkMA=="
TOKEN_URL = "https://mktgaisrch-py-test.victoriouspond-0d0c0c3f.eastus.azurecontainerapps.io/token"

# Jailbreak
# Jailbreak_template_path = C:\\GenAIShare\\JailBreak_Prompts\\cody.yaml

# ADVERSARIAL ATTACK <START>
ADVERSARIAL_ATTACK_NO_OF_RESPONSES = 2
ADVERSARIAL_ATTACK_PROMPT_MIN_SCORE = 0.8
ADVERSARIAL_ATTACK_PROMPT_RESPONSE_MIN_SCORE = 0.5
# ADVERSARIAL_ATTACK_PROMPT_MIN_SCORE = 80
# ADVERSARIAL_ATTACK_PROMPT_RESPONSE_MIN_SCORE = 50
# ADVERSARIAL ATTACK <END>

AI_BOT_URL = "http://127.0.0.1:5001/hospital_chat"

# RED TEAMING <START>
# PYTHON_COMPILER_3_10_URL = r"C:\Users\QEACHNFSTDEVTM\AppData\Local\Programs\Python\Python310\python.exe"
PYTHON_COMPILER_3_10_URL = r"C:\WINDOWS\system32\env3.10\Scripts\python.exe"
RED_TEAM_PYRIT_URL = r"C:\Gen_Ai_Share\qea-gen-ai-assurance-main-latest\qea-gen-ai-assurance\src\GENAI\red_teaming_3_10.py"
# RED TEAMING <END>

config = {
    'JAILBREAK_FLAG': False,
    'ADVERSARIAL_ATTACK_FLAG': False,
    'RED_TEAMING_FLAG': False
}

# Unstructured API key and URL
UNSTRUCTURED_API_KEY = "BKqqXxMQRO1K04EVpDrEkaLLYuL6PR"
UNSTRUCTURED_API_URL = 'https://api.unstructuredapp.io/general/v0/general'

