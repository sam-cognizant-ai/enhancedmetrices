import torch
import torch.nn as nn
import math
import numpy as np
from transformers import AutoModelForCausalLM, AutoTokenizer, GenerationConfig, pipeline, StoppingCriteria, \
    StoppingCriteriaList
from openai import AzureOpenAI

# Initialize Azure OpenAI client for gpt-3.5
client = AzureOpenAI(
    azure_endpoint="https://exploregenaiworkspace.openai.azure.com",
    api_key="0b1d7d099829418fb1293b97f2ae9c23",
    api_version="2023-03-15-preview"
)

# Initialize Azure OpenAI client for gpt-4o
# client = AzureOpenAI(
#     azure_endpoint="https://mktg-service-azure-gpt.openai.azure.com/",
#     api_key="58108d2bc56c4bc0825662a669dcd5e8",
#     api_version="2024-02-15-preview"
# )


class GPTWrapper:
    def __init__(self, model_name, max_new_tokens=512, system_prompt=None):
        # self.model_name = "mktg-gpt-4-omni"  # Specify your Azure GPT model name
        self.model_name = "gpt35exploration"
        self.max_new_tokens = max_new_tokens
        self.system_prompt = system_prompt

    def generate(self, prompt, stop_tokens=['\n'], return_prob=False):
        if self.system_prompt:
            messages = [{"role": "system", "content": self.system_prompt}, {"role": "user", "content": prompt}]
        else:
            messages = [{"role": "user", "content": prompt}]

        response = client.chat.completions.create(
            model=self.model_name,
            messages=messages,
            temperature=0,
            max_tokens=self.max_new_tokens,
            top_p=1,
            logprobs=1 if return_prob else None,  # For Azure API
            frequency_penalty=0.0,
            presence_penalty=0.0,
            stop=stop_tokens
        ).choices[0]

        if return_prob:
            tokens, exp_logprobs = self.wrap_tokens_probs(response.logprobs)
            return response.message.content, tokens, exp_logprobs
        else:
            return response.message.content

    def wrap_tokens_probs(self, logprobs):
        tokens = [item.token for item in logprobs]
        exp_logprobs = [math.exp(item.logprob) for item in logprobs]
        return tokens, exp_logprobs


class LLMCompletion(nn.Module):
    def __init__(self, model_name, max_new_tokens=512, system_prompt=None):
        super(LLMCompletion, self).__init__()
        self.model_name = model_name

        if model_name.startswith("gpt"):
            self.gpt_wrapper = GPTWrapper(model_name, max_new_tokens=max_new_tokens, system_prompt=system_prompt)
        else:
            raise ValueError(f"Unsupported model name: {model_name}")

    @torch.no_grad()
    def forward(self, prompt, stop_tokens=['\n'], return_prob=False):
        if self.model_name.startswith("gpt"):
            response = self.gpt_wrapper.generate(prompt, stop_tokens, return_prob)
            return response
        else:
            raise ValueError(f"Unsupported model name: {self.model_name}")

    def get_stopping_criteria(self, stop_tokens):
        truncate_length = len(self.tokenizer(f'\n')['input_ids'])

        if stop_tokens:
            stop_token_ids = [torch.LongTensor(self.tokenizer(f'\n{stop_token}')['input_ids'][truncate_length:]).cuda()
                              for stop_token in stop_tokens]

            # Define custom stopping criteria object
            class StopOnTokens(StoppingCriteria):
                def __call__(self, input_ids: torch.LongTensor, scores: torch.FloatTensor, **kwargs) -> bool:
                    for stop_ids in stop_token_ids:
                        if torch.eq(input_ids[0][-len(stop_ids):], stop_ids).all():
                            return True
                    return False

            return StoppingCriteriaList([StopOnTokens()])
        else:
            return None
